# 다들 (DADEUL)

후기를 모아 제품을 고르고, 사려는 사람이 모이면 브랜드와 직접 가격을 협상하는 서비스입니다.

---

## 처음이라면

**`CLAUDE.md` 부터 읽으세요.** 사람이든 AI든 여기가 시작점입니다.
원칙 · 용어 · 작업 방식 · 아직 정해지지 않은 것이 모두 들어 있습니다.

AI로 작업한다면 **매 대화마다 `CLAUDE.md` 를 첨부**하세요.
Claude Code를 쓴다면 저장소 루트에 그대로 두면 자동으로 읽습니다.

## 프로토타입 열기

`prototype/index.html` 을 더블클릭하면 됩니다. 빌드 도구도 의존성도 없습니다.

## 폴더

```
├── README.md                      이 문서
├── CLAUDE.md                      ★ 프로젝트 지침. 항상 먼저
├── HANDOFF.md                     확정 사양의 상세 수치
├── docs/
│   ├── collect-products.md        제품 수집 (스마트스토어 기준)
│   ├── collect-reviews.md         후기 수집 (유튜브 중심 · 커버리지 사다리)
│   ├── accuracy.md                ★ 정확도 검증 — 표본 10개로 확인하는 법
│   ├── dadeul-review-service.md   후기 서비스 전체 그림 · 리스크와 대안
│   └── dadeul-service-spec.md     서비스 명세서
├── prototype/
│   └── index.html                 단일 파일 프로토타입
└── verify/
    ├── README.md                  실행법
    └── verify · leaktest · orphan · audit
```

## 파이프라인을 만들기 전에

**`docs/accuracy.md` 를 먼저 읽으세요.**
정확하지 않은 데이터가 한 번 들어오면 후기·라벨·협상까지 전부 오염됩니다.
골든 표본 10개를 먼저 만들고 시작하는 것이 이 프로젝트의 순서입니다.

## 화면을 고쳤다면

```bash
cd prototype
python3 ../verify/verify.py   index.html
python3 ../verify/leaktest.py index.html
python3 ../verify/orphan.py   index.html
```

큰 블록을 교체했거나 정규식을 썼다면 `audit.py` 까지 반드시 돌리세요.
