#!/usr/bin/env python3
"""협상가 노출 자격 검사 — 자격 없는 유저에게 26,300원(p54 협상가)이 새는지 확인"""
import sys, pathlib
from playwright.sync_api import sync_playwright
SRC=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else "index.html").resolve()
DEAL="26,300"; LIST="34,000"

SURFACES=[("홈","S.stack=[{s:'home'}];S.view='grid'"),
          ("카테고리로 찾기","S.stack=[{s:'home'}];S.view='cat'"),
          ("브랜드로 찾기","S.stack=[{s:'home'}];S.view='brand'"),
          ("다시 열릴 수 있어요","S.stack=[{s:'glist'}];S.glist='again'"),
          ("지금 살 수 있어요","S.stack=[{s:'glist'}];S.glist='open'"),
          ("제품 상세","S.stack=[{s:'product',id:'p54'}];S.ptab='rev'"),
          ("검색","S.stack=[{s:'search'}];S.q='앞치마'"),
          ("내 정보","S.stack=[{s:'me'}]")]
CASES=[("연결 안 함 (대기 데이터 주입)","{p54:28900};S.user=null",False),
       ("자격 없음 (등록 안 함)","{}",False),
       ("자격 미달 (23,700 등록)","{p54:23700}",False),
       ("자격 충족 (28,900 등록)","{p54:28900}",True)]

fails=[]
with sync_playwright() as pw:
    br=pw.chromium.launch(); pg=br.new_page(viewport={"width":390,"height":812})
    pg.goto(SRC.as_uri()); pg.wait_for_timeout(300)
    for cname,waits,should in CASES:
        print(f"\n── {cname}")
        for sname,js in SURFACES:
            pg.evaluate(f"S.user=S.user||{{ch:'kakao',id:'카카오 계정'}};S.waits={waits};S.sheet=null;S.drawer=0;S.cat='전체';S.brand=null;{js};draw()")
            pg.wait_for_timeout(70)
            t=pg.evaluate("document.body.innerText")
            leak=DEAL in t
            ok = (leak==should) or (should and not leak and sname in("검색","다시 열릴 수 있어요"))
            print(f"   {'✅' if ok else '❌'} {sname:<18} 협상가 {'노출' if leak else '가림'}")
            if not ok: fails.append(f"{cname} / {sname}")
    # 구매 버튼 도달 가능성
    print("\n── 「협상가로 사러 가기」 버튼")
    for cname,waits,should in CASES:
        pg.evaluate(f"S.user=S.user||{{ch:'kakao',id:'카카오 계정'}};S.waits={waits};S.stack=[{{s:'product',id:'p54'}}];draw()"); pg.wait_for_timeout(70)
        has=pg.evaluate("""!!document.querySelector('[data-a="deal:p54"]')""")
        ok=(has==should)
        print(f"   {'✅' if ok else '❌'} {cname:<22} {'있음' if has else '없음'}")
        if not ok: fails.append(f"버튼 / {cname}")
    br.close()
print("\n"+"="*50)
print("판정:", "통과 ✅" if not fails else "실패 ❌ "+str(fails))
