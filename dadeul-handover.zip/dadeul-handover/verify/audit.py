#!/usr/bin/env python3
"""구조 감사 — 편집 사고로 무언가 조용히 사라지지 않았는지 원본과 대조한다.
사용법: python3 audit.py [현재 index.html] [기준이 되는 원본 index.html]

과거에 실제로 터진 사고를 겨냥한다:
  · 정규식 치환이 선언(CATS·byId·dropWhy)까지 삭제
  · 블록 교체 시 case 핸들러 유실
  · 줄 단위 편집이 닫는 태그 개수를 어긋나게 함
"""
import sys, re, json, pathlib
from playwright.sync_api import sync_playwright

CUR = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "index.html").resolve()
REF = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else "/mnt/user-data/uploads/index.html")

# 의도적으로 없앤 것 — 새로 생기면 여기에 추가한다
REMOVED_OK = {"noneL", "toggleBrand", "toggleFoot"}

fail = []
cur = CUR.read_text(encoding="utf-8")
ref = REF.read_text(encoding="utf-8") if REF.exists() else None

print("=" * 62)
print(f"감사 대상  {CUR}")
print(f"기준 원본  {REF if ref else '(없음 — ① 생략)'}")
print("=" * 62)

# ── ① 선언·핸들러·CSS 유실
if ref:
    print("\n① 원본에 있었는데 지금 없는 것")
    for label, pat, fl in [("최상위 const/let", r'^\s*(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=', re.M),
                           ("function 선언",   r'^\s*function\s+([A-Za-z_$][\w$]*)', re.M),
                           ("화면 V.*",        r'V\.([A-Za-z0-9_]+)\s*=', 0),
                           ("액션 핸들러",     r"case'([A-Za-z0-9_]+)'", 0),
                           ("CSS 클래스",      r'^\.([a-zA-Z][\w-]*)', re.M),
                           ("CSS 변수",        r'(--[a-zA-Z][\w-]*)\s*:', 0)]:
        rx = re.compile(pat, fl) if fl else pat
        lost = sorted(set(re.findall(rx, ref)) - set(re.findall(rx, cur)) - REMOVED_OK)
        print(f"   {'❌' if lost else '✅'} {label:<16} {lost if lost else '유실 없음'}")
        if lost:
            fail.append(f"{label} 유실: {lost}")

# ── ② 제품 데이터
def items(text):
    b = text[text.index("const P=["):]
    b = b[:b.index("\nconst byId")]
    return {o["id"]: o for o in (
        json.loads(re.sub(r'([{,])([a-zA-Z_][a-zA-Z0-9_]*):', r'\1"\2":', l.strip().rstrip(",")))
        for l in b.split("\n") if l.strip().startswith('{id:"'))}

if ref:
    a, b = items(ref), items(CUR.read_text(encoding="utf-8"))
    print("\n② 제품 데이터")
    print(f"   {'✅' if len(a)==len(b) else '❌'} 제품 수 {len(a)} → {len(b)}")
    if len(a) != len(b):
        fail.append(f"제품 수 {len(a)}→{len(b)}")
    fa = {f for v in a.values() for f in v}
    fb = {f for v in b.values() for f in v}
    lost = sorted(fa - fb)
    print(f"   {'❌' if lost else '✅'} 사라진 필드 종류 {lost if lost else '없음'}")
    if lost:
        fail.append(f"필드 종류 유실: {lost}")
    diff = [(k, f) for k in a for f in set(a[k]) | set(b.get(k, {})) if a[k].get(f) != b[k].get(f)]
    print(f"   ℹ  값이 바뀐 필드 {len(diff)}건 — 의도한 변경인지 눈으로 확인:")
    for k, f in diff:
        print(f"        {k}.{f}: {str(a[k].get(f))[:30]} → {str(b[k].get(f))[:30]}")

# ── ③④ 태그 균형 · DOM 구조
BAL = r"""() => {
  const bal = h => ({
    div:(h.match(/<div(?=[\s>])/g)||[]).length-(h.match(/<\/div>/g)||[]).length,
    span:(h.match(/<span(?=[\s>])/g)||[]).length-(h.match(/<\/span>/g)||[]).length,
    button:(h.match(/<button(?=[\s>])/g)||[]).length-(h.match(/<\/button>/g)||[]).length});
  const out=[]; let n=0;
  const call = k => k==='done' ? V.done('wait','p54') : (V[k].length ? V[k]('p54') : V[k]());
  for (const k of Object.keys(V)) {
    let h; try { h = call(k); } catch(e){ out.push([k,'호출 실패 '+e.message]); continue; }
    if (typeof h!=='string') continue;
    n++; const b=bal(h); if (b.div||b.span||b.button) out.push([k, JSON.stringify(b)]);
  }
  const u=S.user;
  for (const st of [u,null]) { S.user=st; n++; const b=bal(V.me());
    if (b.div||b.span||b.button) out.push(['me '+(st?'연결됨':'비연결'), JSON.stringify(b)]); }
  S.user=u;
  const keep=S.sheet;
  for (const sh of ['price:p1','login:p1','code:p1','filter:x','sort:x','edit:x','quit:x','site:p1','elink:p2','pub:x','unpub:x']) {
    S.sheet=sh; let h; try{h=sheetHTML()}catch(e){out.push(['sheet '+sh,'호출 실패 '+e.message]);continue}
    n++; const b=bal(h); if (b.div||b.span||b.button) out.push(['sheet '+sh, JSON.stringify(b)]);
  }
  S.sheet=keep;
  // 파싱된 DOM 의 중첩 깊이 — 닫힘이 빠지면 비정상적으로 깊어진다
  const deep=[];
  const u2=S.user;
  for (const s of ['home','glist','reviews','me','waits','buys','admin','product','deal']) {
    S.stack=[{s,id:'p54'}]; S.sheet=null; S.drawer=0; draw();
    const app=document.getElementById('app'); let max=0;
    (function walk(el,d){ if(d>max)max=d; for(const c of el.children) walk(c,d+1); })(app,0);
    if (max>16 || app.innerHTML.length<400) deep.push(`${s}: 깊이 ${max} · ${app.innerHTML.length}자`);
  }
  S.user=u2; S.stack=[{s:'home'}]; draw();
  return {n, out, deep};
}"""
with sync_playwright() as pw:
    br = pw.chromium.launch()
    pg = br.new_page(viewport={"width": 390, "height": 900})
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(CUR.as_uri())
    pg.wait_for_timeout(400)
    r = pg.evaluate(BAL)
    br.close()

print(f"\n③ 태그 균형 ({r['n']}개 화면·시트)")
print("   " + ("\n   ".join("❌ " + k + ": " + v for k, v in r["out"]) if r["out"]
               else "✅ div / span / button 이 모두 짝을 이룸"))
if r["out"]:
    fail.append(f"태그 불균형 {len(r['out'])}건")

print("\n④ 파싱된 DOM")
print("   " + ("\n   ".join("❌ " + d for d in r["deep"]) if r["deep"] else "✅ 비정상 중첩·빈 렌더 없음"))
print("   " + (f"❌ pageerror {errs}" if errs else "✅ pageerror 없음"))
if r["deep"] or errs:
    fail.append("DOM 이상")

print("\n" + "=" * 62)
print("판정:", "통과 ✅" if not fail else "실패 ❌ " + " / ".join(fail))
