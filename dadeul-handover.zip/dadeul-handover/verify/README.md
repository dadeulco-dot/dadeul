# 검증 스크립트

```bash
pip install playwright && playwright install chromium
cd ../prototype

python3 ../verify/verify.py   index.html   # 화면 렌더 · 버튼-핸들러 대조 · 줄바꿈
python3 ../verify/leaktest.py index.html   # 협상가 노출 자격
python3 ../verify/orphan.py   index.html   # 3개 폭 줄바꿈 품질
python3 ../verify/audit.py    index.html 이전_index.html   # 구조 유실 감사
```

문법 검사는 따로 돌립니다.

```bash
sed -n '/^<script>/,/^<\/script>/p' index.html | sed '1d;$d' > /tmp/a.js && node --check /tmp/a.js
```

`index.html`을 고치면 앞의 셋은 **항상** 돌리세요.
큰 블록을 교체했거나 정규식을 썼다면 `audit.py`까지.
