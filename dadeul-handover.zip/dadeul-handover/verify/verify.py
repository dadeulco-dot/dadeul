#!/usr/bin/env python3
# JS_ROUND_NOTE: 가격 계단 검증은 파이썬 round()가 아니라 페이지의 ladder()를 그대로 호출할 것.
#   파이썬은 은행가 반올림(32.5→32), JS Math.round 는 올림(32.5→33) 이라 결과가 갈린다.
"""다들 프로토타입 검증 하네스
사용법: python3 verify.py [index.html 경로]
① 전체 화면 렌더  ② 콘솔 오류 수집  ③ 버튼-핸들러 대조  ④ 줄바꿈(마지막 줄 2자 이하) 탐지
"""
import sys, json, pathlib
from playwright.sync_api import sync_playwright

SRC = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "index.html").resolve()

SCREENS = ["home","glist","rlist","reviews","search","compare","cmp","cmpSearch",
           "list","excluded","method","me","noti","log","rules","admin","waits","buys"]
PROD_IDS = ["p1","p2","p3","p5","p7","p9","p11","p22"]   # 판정·협상 상태 골고루
SHEETS   = ["price:p1","login:p1","code:p1","filter:x","sort:x","edit:x",
            "site:p1","elink:p2","pub:x","unpub:x","quit:x"]
ATABS    = ["cand","job","aud","pub","nego","link","done","kpi"]
KTABS    = ["core","churn","cust","acq"]

errors, warns = [], []

with sync_playwright() as pw:
    br = pw.chromium.launch()
    pg = br.new_page(viewport={"width": 390, "height": 812})
    pg.on("console", lambda m: errors.append(f"[console.{m.type}] {m.text}") if m.type == "error" else None)
    pg.on("pageerror", lambda e: errors.append(f"[pageerror] {e}"))
    pg.goto(SRC.as_uri())
    pg.wait_for_timeout(300)

    def render(desc, js):
        before = len(errors)
        try:
            pg.evaluate(js)
            pg.wait_for_timeout(60)
            n = pg.evaluate("document.getElementById('app').innerHTML.length")
            if n < 500:
                warns.append(f"{desc}: 렌더 결과가 {n}자로 비정상적으로 짧음")
        except Exception as ex:
            errors.append(f"[{desc}] {ex}")
        for e in errors[before:]:
            errors[errors.index(e)] = f"{desc} → {e}"

    # ① 기본 화면
    for s in SCREENS:
        render(f"화면 {s}", f"S.stack=[{{s:'{s}'}}];S.sheet=null;S.drawer=0;draw()")
    # 제품/협상/인증/신고/완료
    for pid in PROD_IDS:
        for s in ["product","deal","verify","report"]:
            render(f"{s}:{pid}", f"S.stack=[{{s:'{s}',id:'{pid}'}}];S.sheet=null;draw()")
        for t in ["rev","info"]:
            render(f"product:{pid}/{t}", f"S.ptab='{t}';S.stack=[{{s:'product',id:'{pid}'}}];draw()")
    for s in ["wait","verified","reported"]:
        render(f"완료 {s}", f"S.stack=[{{s:'{s}',id:'p1'}}];draw()")
    # 드로어
    render("드로어", "S.stack=[{s:'home'}];S.drawer=1;draw()")
    render("드로어 카테고리 펼침", "S.opencat='조리팬';draw()")
    render("드로어 닫기", "S.drawer=0;S.opencat=null;draw()")
    # 시트
    for sh in SHEETS:
        render(f"시트 {sh}", f"S.stack=[{{s:'home'}}];S.tmp=null;S.sheet='{sh}';draw()")
    render("시트 해제", "S.sheet=null;draw()")
    # 홈 뷰 모드 / 섹션
    for v in ["grid","cat","brand"]:
        render(f"홈 view={v}", f"S.stack=[{{s:'home'}}];S.view='{v}';S.cat='전체';S.brand=null;draw()")
    render("홈 복귀", "S.view='grid';draw()")
    for k in ["open","talking","gathering","again","pending","hold","postponed","none"]:
        render(f"glist:{k}", f"S.glist='{k}';S.stack=[{{s:'glist'}}];draw()")
    for k in ["many","clean","long","thin"]:
        render(f"rlist:{k}", f"S.rlist='{k}';S.stack=[{{s:'rlist'}}];draw()")
    # 운영 콘솔
    for t in ATABS:
        render(f"콘솔 {t}", f"S.stack=[{{s:'admin'}}];S.atab='{t}';draw()")
    for k in KTABS:
        render(f"콘솔 지표/{k}", f"S.atab='kpi';S.ktab='{k}';draw()")
    # 검색 상태
    render("검색 결과 있음", "S.stack=[{s:'search'}];S.q='팬';draw()")
    render("검색 결과 없음", "S.stack=[{s:'search'}];S.q='존재하지않는제품';draw()")
    render("검색 초기화", "S.q='';draw()")
    # 로그인 상태
    render("로그인 상태 홈", "S.user={ch:'kakao',id:'카카오 계정'};S.stack=[{s:'me'}];draw()")
    render("대기 등록 보유", "S.waits={p1:39800,p5:23700};S.stack=[{s:'me'}];draw()")
    render("구매 보유", "S.bought={p9:buyRec(byId('p9'))};S.stack=[{s:'buys'}];draw()")
    render("기다리는 것 다건", "S.waits={p54:28900,p1:26700,p12:34500,p11:39500,p14:30300};S.stack=[{s:'waits'}];draw()")
    render("기다리는 것 비어있음", "S.waits={};S.stack=[{s:'waits'}];draw()")
    render("구매한 것 비어있음", "S.bought={};S.stack=[{s:'buys'}];draw()")
    render("내 정보 비어있음", "S.stack=[{s:'me'}];draw()")
    # 자격 분기 — 협상가 노출은 canBuy 인 사람에게만
    render("비자격 홈", "S.waits={};S.stack=[{s:'home'}];draw()")
    render("비자격 상세 p54", "S.stack=[{s:'product',id:'p54'}];draw()")
    render("자격 미달 등록", "S.waits={p54:23700};S.stack=[{s:'product',id:'p54'}];draw()")
    render("자격 충족 등록", "S.waits={p54:28900};S.stack=[{s:'product',id:'p54'}];draw()")
    render("자격 충족 홈", "S.stack=[{s:'home'}];draw()")
    render("자격 충족 협상", "S.stack=[{s:'deal',id:'p54'}];draw()")
    render("내 정보 자격", "S.stack=[{s:'me'}];draw()")
    render("초기화", "S.waits={};S.stack=[{s:'home'}];draw()")

    # ③ 버튼-핸들러 대조
    orphan = pg.evaluate("""() => {
      const html = document.getElementById('app').innerHTML;
      return [...new Set([...html.matchAll(/data-a="([a-zA-Z0-9_]+)/g)].map(m=>m[1]))];
    }""")

    # ④ 줄바꿈 검사 — 마지막 줄이 2자 이하인 텍스트 블록
    pg.evaluate("S.stack=[{s:'home'}];S.sheet=null;S.drawer=0;S.view='grid';draw()")
    pg.wait_for_timeout(80)
    orphans_line = pg.evaluate("""() => {
      const out=[];
      document.querySelectorAll('.pname,.h2,.h3,.sub,.meta,.tiny,.h1').forEach(el=>{
        const t=el.textContent.trim(); if(t.length<6) return;
        const r=el.getClientRects(); if(r.length<2) return;
        const range=document.createRange(); range.selectNodeContents(el);
        const rects=[...range.getClientRects()].filter(x=>x.width>1);
        if(rects.length<2) return;
        const last=rects[rects.length-1], w=el.getBoundingClientRect().width;
        if(last.width < w*0.14) out.push(t.slice(0,40));
      });
      return [...new Set(out)];
    }""")
    br.close()

src = SRC.read_text()
import re
handlers = set(re.findall(r"case'([a-zA-Z0-9_]+)'", src))
missing = [a for a in orphan if a not in handlers]

print("=" * 56)
print(f"검증 대상: {SRC}")
print("=" * 56)
print(f"① 문법 ....... 별도 node --check 로 확인")
print(f"② 렌더 오류 ... {len(errors)}건")
for e in errors[:30]:
    print("   ✗", e)
print(f"③ 미매칭 버튼 . {len(missing)}건 {missing if missing else ''}")
print(f"④ 짧은 끝줄 ... {len(orphans_line)}건")
for o in orphans_line[:15]:
    print("   ·", o)
if warns:
    print(f"⚠ 경고 ........ {len(warns)}건")
    for w in warns[:15]:
        print("   !", w)
print("=" * 56)
print("판정:", "통과 ✅" if not errors and not missing else "실패 ❌")
