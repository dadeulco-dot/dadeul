#!/usr/bin/env python3
"""줄바꿈 품질 검사 — 마지막 줄이 지나치게 짧은(고아 줄) 텍스트를 전 화면에서 찾는다.
사용법: python3 orphan.py [index.html] [--all]
"""
import sys, pathlib, json
from playwright.sync_api import sync_playwright

SRC = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "index.html").resolve()
SHOW_ALL = "--all" in sys.argv

STATES = []
for s in ["home","glist","rlist","reviews","search","compare","cmp","cmpSearch",
          "list","excluded","method","me","noti","log","rules","admin","waits","buys"]:
    STATES.append((s, f"S.stack=[{{s:'{s}'}}];S.sheet=null;S.drawer=0"))
for pid in ["p1","p54","p11","p22","p14","p3"]:
    for sc in ["product","deal","verify","report"]:
        STATES.append((f"{sc}:{pid}", f"S.stack=[{{s:'{sc}',id:'{pid}'}}];S.sheet=null"))
    STATES.append((f"product:{pid}/info", f"S.ptab='info';S.stack=[{{s:'product',id:'{pid}'}}]"))
for s in ["wait","verified","reported"]:
    STATES.append((s, f"S.stack=[{{s:'{s}',id:'p54'}}]"))
for k in ["open","talking","gathering","again","pending","hold","postponed","none"]:
    STATES.append((f"glist:{k}", f"S.stack=[{{s:'glist'}}];S.glist='{k}'"))
for sh in ["price:p1","login:p1","code:p1","filter:x","sort:x","site:p1","elink:p2","pub:x","unpub:x","edit:x","quit:x"]:
    STATES.append((f"sheet {sh}", f"S.stack=[{{s:'home'}}];S.tmp=null;S.sheet='{sh}'"))
for t in ["cand","job","aud","pub","nego","link","done","kpi"]:
    STATES.append((f"admin/{t}", f"S.stack=[{{s:'admin'}}];S.atab='{t}'"))
STATES.append(("drawer", "S.stack=[{s:'home'}];S.drawer=1;S.sec='state'"))
STATES.append(("home/cat", "S.stack=[{s:'home'}];S.drawer=0;S.view='cat'"))
STATES.append(("home/brand", "S.stack=[{s:'home'}];S.view='brand'"))

PROBE = """(minRatio) => {
  const out = [];
  const seen = new Set();
  document.querySelectorAll('#app *').forEach(el => {
    if (el.children.length) return;                      // 잎 노드만
    const t = (el.textContent || '').trim();
    if (t.length < 12) return;                           // 짧은 문구는 대상 아님
    const range = document.createRange();
    range.selectNodeContents(el);
    const rects = [...range.getClientRects()].filter(r => r.width > 1 && r.height > 1);
    if (rects.length < 2) return;                        // 한 줄짜리는 대상 아님
    const last = rects[rects.length - 1];
    const wide = Math.max(...rects.map(r => r.width));
    const ratio = last.width / wide;
    if (ratio >= minRatio) return;
    const tail = t.slice(-14);
    const key = t.slice(0, 40) + '|' + rects.length;
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ text: t.slice(0, 70), tail, lines: rects.length,
               ratio: Math.round(ratio * 100), cls: el.className || el.tagName });
  });
  return out;
}"""

MIN = 0.30
SENT = """() => {
  const out = [];
  document.querySelectorAll('#app *').forEach(el => {
    if (el.children.length) return;
    const t = (el.textContent || '').trim();
    if (!/\\. \\S/.test(t)) return;                      // 두 문장 이상만 대상
    const rg = document.createRange(); rg.selectNodeContents(el);
    const n = [...rg.getClientRects()].filter(r => r.width > 1).length;
    const sent = t.split(/\\. (?=\\S)/).length;
    if (n > 1 && n !== sent) out.push(`${n}줄/${sent}문장 · ${t.slice(0, 56)}`);
  });
  return [...new Set(out)];
}"""
OVERFLOW = """() => {
  const out = [];
  document.querySelectorAll('#app *').forEach(el => {
    if (el.scrollWidth > el.clientWidth + 4 && el.clientWidth > 0) {
      const st = getComputedStyle(el);
      if (st.overflowX === 'visible' && st.whiteSpace !== 'nowrap' && !el.className.includes('body'))
        out.push((el.className || el.tagName) + ' ⇢ ' + (el.textContent || '').trim().slice(0, 40));
    }
  });
  return [...new Set(out)];
}"""
found = {}
overflow = {}
midsent = {}   # 문장 중간에서 줄이 끊기는 문구 — 짧은 설명문은 bySent() 로 문장 단위 줄바꿈
with sync_playwright() as pw:
    br = pw.chromium.launch()
    for W in (360, 390, 430):        # 갤럭시 / 아이폰 표준 / 아이폰 플러스
        pg = br.new_page(viewport={"width": W, "height": 900})
        pg.goto(SRC.as_uri()); pg.wait_for_timeout(350)
        for name, js in STATES:
            try:
                pg.evaluate(js + ";draw()")
                pg.wait_for_timeout(45)
                for h in pg.evaluate(PROBE, MIN):
                    k = h["text"]
                    if k not in found:
                        h["where"] = f"{name} @{W}"
                        found[k] = h
                for o in pg.evaluate(OVERFLOW):
                    overflow.setdefault(o, f"{name} @{W}")
                if W == 390:
                    for o in pg.evaluate(SENT):
                        midsent.setdefault(o, name)
            except Exception as e:
                print(f"  ! {name} @{W}: {e}")
        pg.close()
    br.close()

hits = sorted(found.values(), key=lambda h: h["ratio"])
print("=" * 62)
print(f"마지막 줄이 전체 폭의 {int(MIN*100)}% 미만인 문구: {len(hits)}건")
print("=" * 62)
for h in (hits if SHOW_ALL else hits[:40]):
    print(f"[{h['ratio']:>2}% · {h['lines']}줄] {h['where']}  ({h['cls'][:22]})")
    print(f"    {h['text']}")
    print(f"    끝줄 ⇢ …{h['tail']}")
print("=" * 62)
print(f"가로 넘침(어절 단위 줄바꿈 부작용): {len(overflow)}건")
for k, v in list(overflow.items())[:15]:
    print(f"   ! {v}  {k}")
print(f"문장 중간에서 끊김(참고 · 본문 문단은 허용): {len(midsent)}건")
for k, v in list(midsent.items())[:10]:
    print(f"   · {v}  {k}")
print("=" * 62)
print("판정:", "통과 ✅" if not hits and not overflow else f"고아 줄 {len(hits)}건 · 넘침 {len(overflow)}건 ❌")
