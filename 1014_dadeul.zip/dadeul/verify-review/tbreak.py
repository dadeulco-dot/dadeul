import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
"""중분류 이름 줄바꿈 — 결과까지 자동 판정
   홈 중분류 버튼 · 카테고리 메뉴 왼쪽 줄에서 낱말 중간에서 끊기지 않는지 (「베이스 / 메이크업」처럼 정한 자리 · 「·」 뒤 · 띄어쓰기에서만)
   휴대폰 360 · 390 · 430 · PC 1024 · 1440 × 세 대분류"""
import asyncio,sys
from playwright.async_api import async_playwright
# 버튼마다 줄별 글자를 뽑아, 낱말 중간에서 끊긴 줄이 있는지 봄
JS="""(sel)=>[...document.querySelectorAll(sel)].map(b=>{const tw=document.createTreeWalker(b,NodeFilter.SHOW_TEXT);const lines={};let n;
 while(n=tw.nextNode()){for(let i=0;i<n.length;i++){const r=document.createRange();r.setStart(n,i);r.setEnd(n,i+1);const rc=r.getClientRects()[0];if(!rc)continue;const k=Math.round(rc.top);lines[k]=(lines[k]||'')+n.data[i]}}
 return Object.keys(lines).sort((a,b)=>a-b).map(k=>lines[k].replace(/[\\u2060\\u200b]/g,'').trim())})"""
async def m(url=URL):
  bad=[];seen=0
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W in [('mo',360),('mo',390),('mo',430),('pc',1024),('pc',1440)]:
      pg=await b.new_page(viewport={'width':W,'height':900});await pg.goto(url);await pg.wait_for_timeout(300)
      for dom in ['뷰티','육아용품','주방용품']:
        for st,sel in [(f"S.screen='home';S.hdom='{dom}';S.hdomSet=true",'.mids .mid'),(f"S.screen='cats';S.cdom='{dom}';S.prev=null",'.crail button')]:
          if view=='pc' and 'cats' in st: continue
          await pg.evaluate(f"S.view='{view}';{st};draw()")
          fulls=await pg.evaluate(f"[...document.querySelectorAll('{sel}')].map(e=>e.textContent.replace(/[\\u2060\\u200b]/g,'').trim())")
          for lines,full in zip(await pg.evaluate(JS,sel),fulls):
            seen+=1
            if len(lines)>1:
              # 허용: 「메이크업」으로 시작하는 줄, 앞줄이 「·」로 끝남, 띄어쓰기에서 끊김(줄이 낱말 단위)
              ok=all(l2.startswith('메이크업') or l1.endswith('·') or True for l1,l2 in zip(lines,lines[1:]))
              joined=''.join(lines)
              words=[w for w in joined.replace('·',' ').split()]
              mid_word=any(not(l2.startswith('메이크업') or l1.endswith('·') or (l1+' '+l2) in full) for l1,l2 in zip(lines,lines[1:]))
              if mid_word: bad.append((view,W,sel.split()[0],lines))
      await pg.close()
    await b.close()
  print('중분류 버튼 · 메뉴',seen,'개 · 낱말 중간에서 끊긴 것',len(bad))
  for x in bad[:12]: print('  ',x)
  print('판정 오류',[f'{v}{w} {s} {l}' for v,w,s,l in bad])
asyncio.run(m())
