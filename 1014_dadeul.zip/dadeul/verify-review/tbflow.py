import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""브랜드 — 결과까지 자동 판정 (CLAUDE.md 2-6 · HANDOFF.md 1장)
   상세의 브랜드 이름 → 브랜드 화면 · 묶음 = 그 브랜드 제품의 소분류(원자료 그대로) · 브랜드 평점 · 브랜드 라벨 없음
   · 새 제품 알림 · 뒤로 (상세 ↔ 브랜드 ↔ 모아보기) · 초성 이동 · 검색 자동완성의 브랜드 → 브랜드 화면"""
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,brand:S.brand,pid:S.pid,follow:Object.keys(S.follow).filter(k=>S.follow[k])})"
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'detail',pid:'p2',follow:{{}},resetTop:1}});draw()")
      async def c(sel,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return await pg.evaluate(ST)
      s=await c('.blink')
      expg=await pg.evaluate("[...new Set(ALL().filter(x=>x.brand==='무이').map(x=>x.sub))]")
      got=await pg.evaluate("[...document.querySelectorAll('[data-a^=\"bsub:\"]')].map(e=>e.dataset.a.slice(5)).filter(Boolean)")
      J.want('① 상세의 브랜드 「무이」 → 브랜드 화면 · 고를 수 있는 소분류 = 무이 제품의 소분류',s['screen']=='brand' and s['brand']=='무이' and sorted(got)==sorted(expg),(got,expg))
      # 쇼핑몰형 — 소분류 · 정렬 · 필터 · 비교 (기대값은 원자료에서)
      ids=lambda: pg.evaluate("[...document.querySelectorAll('.bcd [data-a^=\"open:\"]')].map(e=>e.dataset.a.slice(5))")
      raw={x['id']:x for x in await pg.evaluate("ALL().filter(x=>x.brand==='무이').map(x=>({id:x.id,sub:x.sub,price:x.price,n:x.n,good:labOf(x)==='대체로 만족'}))")}
      await c('[data-a="bsub:프라이팬"]');got=await ids()
      J.want('①-2 소분류 「프라이팬」 → 무이의 프라이팬만',set(got)=={i for i,x in raw.items() if x['sub']=='프라이팬'},got)
      J.want('①-3 「같은 프라이팬 N종과 비교」 → 그 소분류 전체 목록으로 이어짐',await pg.evaluate("!!document.querySelector('.bhd [data-a=\"list:프라이팬\"]')"))
      await c('[data-a="bsub:"]')
      if view=='mo': await c('[data-a="sheet:bsort"]');await c('[data-a="bsortk:priceD"]')
      else: await pg.select_option('select[data-change="bsort"]','priceD');await pg.wait_for_timeout(150)
      got=await ids();J.want('①-4 가격 높은 순 (표본 부족은 어떤 정렬에서도 맨 뒤)',got==[i for i,_ in sorted(raw.items(),key=lambda kv:(kv[1]['n']<30,-kv[1]['price']))],got)
      if view=='mo': await c('[data-a="sheet:bfilter"]')
      await c('[data-a="bgood"]')
      if view=='mo': await c('[data-a="close"]')
      got=await ids();J.want('①-5 「대체로 만족」만',set(got)=={i for i,x in raw.items() if x['good']},got)
      await c('[data-a="bfreset"]')
      await c('.bcd [data-a="cmp:p2"]')
      J.want('①-6 카드의 「+ 비교」로 비교함에 담김 · 비교함 띠가 나타남',await pg.evaluate("!!S.cmp.p2") and await pg.evaluate("!!document.querySelector('.cfloat,.tray')"))
      await c('.bcd [data-a="open:p2"]')
      # 뒤로 — 모바일은 상단 ←, PC 는 상세에 뒤로 버튼이 없어 같은 동작(dback)을 직접 냄 (브라우저 뒤로 가기에 해당)
      if view=='mo': await c('[data-a="dback"]')
      else: await pg.evaluate("(()=>{const b=document.createElement('button');b.dataset.a='dback';document.body.appendChild(b);b.click();b.remove()})()");await pg.wait_for_timeout(150)
      st=await pg.evaluate("({screen:S.screen,brand:S.brand,sort:S.bsort})")
      J.want('①-7 제품 상세 → 뒤로 → 브랜드 화면 · 고른 정렬 그대로',st=={'screen':'brand','brand':'무이','sort':'priceD'},st)
      await pg.evaluate("S.cmp={};draw()")
      body=await pg.evaluate("document.body.innerText")   # 화면 전체 (PC 는 첫 .wrap 이 상단 메뉴라 본문을 못 읽었음)
      J.want('② 브랜드 평점 · 브랜드 라벨 없음 (라벨은 제품마다)','평점' not in body and '브랜드 라벨' not in body and '다들은 브랜드를 평가하지 않아요' in body)
      s=await c('[data-a="follow:무이"]');J.want('③ 새 제품 알림 켜기',s['follow']==['무이'])
      s=await c('[data-a="brandback"]');J.want('④ 뒤로 → 원래 상세',(s['screen'],s['pid'])==('detail','p2'))
      if view=='mo':
        await pg.evaluate("S.screen='cats';S.prev=null;draw()")
        J.want('⑤-1 카테고리 탭 맨 위에 「카테고리 | 브랜드」 두 칸',await pg.evaluate("[...document.querySelectorAll('.csegtab button')].map(e=>e.innerText.trim())")==['카테고리','브랜드'])
        s=await c('[data-a="catseg:brand"]')
        J.want('⑤ 「브랜드」 칸 → 모아보기 · 하단 탭은 카테고리 그대로',s['screen']=='brands' and (await pg.evaluate("(document.querySelector('.tab[aria-current=\"page\"]')||{}).innerText||''")).startswith('카테고리'))
      else:
        await pg.evaluate("S.screen='home';S.mega=null;draw()")
        J.want('⑤-1 PC 홈 상단 메뉴 대분류 옆에 「브랜드」',await pg.evaluate("[...document.querySelectorAll('.gnb .menu button')].map(e=>e.innerText.trim())")==['뷰티','육아용품','주방용품','브랜드'])
        s=await c('.gnb [data-a="brands"]')
        J.want('⑤ 상단 메뉴 「브랜드」 → 모아보기 · 메뉴에 지금 위치 표시',s['screen']=='brands' and 'on' in await pg.evaluate("document.querySelector('.gnb [data-a=\"brands\"]').className"))
      # 고정된 머리 중 가장 아래 (PC 상단 메뉴 · 모바일 상단 막대 · 탭 안이면 「카테고리 | 브랜드」 두 칸까지)
      # 대분류 칩 — 고르면 그 대분류 제품이 있는 브랜드만 · 자음 칩도 그 안의 자음만 · 줄의 소분류도 그 대분류 것만
      chips=await pg.evaluate("[...document.querySelectorAll('[data-a^=\"bdom:\"]')].map(e=>e.innerText.replace(/\\s+/g,' ').trim())")
      J.want('⑤-2 대분류 칩 = 전체 · 뷰티 · 육아용품 · 주방용품 (브랜드 수와 함께)',[x.split(' ')[0] for x in chips]==['전체','뷰티','육아용품','주방용품'],chips)
      rawb=await pg.evaluate("ALL().map(x=>({b:x.brand,dom:midOf(x.sub).dom,sub:x.sub}))")
      for dom in ['육아용품','뷰티']:
        await c(f'[data-a="bdom:{dom}"]')
        got=await pg.evaluate("[...document.querySelectorAll('.bidx [data-a^=\"brand:\"]')].map(e=>e.dataset.a.slice(6))")
        exp=sorted({r['b'] for r in rawb if r['dom']==dom})
        subs=await pg.evaluate("[...document.querySelectorAll('.bidx .srow2 > span:first-child .t-cap')].map(e=>e.innerText).join(' · ')")   # 브랜드 이름 아래 소분류 줄만 (오른쪽 「N개」는 빼고)
        okSub=all(s2 in {r['sub'] for r in rawb if r['dom']==dom} for s2 in subs.split(' · ') if s2)
        jamo=await pg.evaluate("[...document.querySelectorAll('[data-a^=\"bjump:\"]')].map(e=>e.dataset.a.slice(6))")
        expj=await pg.evaluate(f"[...new Set({exp}.map(choKey))]")
        J.want(f'⑤-3 「{dom}」 → 그 대분류 브랜드만 · 줄의 소분류도 {dom} 것만 · 자음 칩도 그 안의 것만',sorted(got)==exp and okSub and jamo==expj,(len(got),len(exp),jamo))
      await c('[data-a="bdom:"]')
      J.want('⑤-4 「전체」로 돌아가면 모든 브랜드',len(await pg.evaluate("[...document.querySelectorAll('.bidx [data-a^=\"brand:\"]')]"))==len({r['b'] for r in rawb}))
      hb=await pg.evaluate("Math.round(Math.max(...['.gnb','.top','.csegtab'].map(q=>document.querySelector(q)).filter(Boolean).map(e=>e.getBoundingClientRect().bottom)))")
      bad=[]
      for k in await pg.evaluate("[...document.querySelectorAll('[data-a^=\"bjump:\"]')].map(e=>e.dataset.a.slice(6))"):
        await pg.evaluate(f"document.querySelector('[data-a=\"bjump:{k}\"]').click()");await pg.wait_for_timeout(900)
        t=await pg.evaluate(f"Math.round(document.getElementById('bk-{k}').getBoundingClientRect().top)")
        if not (hb-1<=t<=hb+40): bad.append((k,t))
      J.want('⑥ 초성마다 그 묶음이 상단 머리 바로 아래로 (가려지지 않음 · 마지막 「ㅎ」 포함)',not bad,(hb,bad))
      # 안내(토스트)가 사라지는 순간에 하던 스크롤이 끊기지 않아야 함 — 예전엔 사라질 때 화면 전체를 다시 그려 멈췄음
      await pg.evaluate("say('시험용 안내')");await pg.wait_for_timeout(2000)
      await pg.evaluate("document.querySelector('[data-a=\"bjump:ㅂ\"]').click()");await pg.wait_for_timeout(1200)
      t=await pg.evaluate("Math.round(document.getElementById('bk-ㅂ').getBoundingClientRect().top)")
      J.want('⑥-2 안내가 사라지는 순간의 초성 이동도 끝까지 (스크롤이 끊기지 않음)',hb-1<=t<=hb+40 and await pg.evaluate("!document.querySelector('.toast')"),(hb,t))
      s=await c('[data-a="brand:하로"]');J.want('⑦ 하로 → 브랜드 화면',(s['screen'],s['brand'])==('brand','하로'))
      s=await c('[data-a="brandback"]');J.want('⑧ 뒤로 → 모아보기 (들어온 곳)',s['screen']=='brands')
      if view=='mo':
        J.want('⑧-1 탭 안의 모아보기로 돌아옴 (두 칸 그대로)',await pg.evaluate("!!document.querySelector('.csegtab')"))
        s=await c('[data-a="catseg:cat"]');J.want('⑧-2 「카테고리」 칸으로 돌아가기',s['screen']=='cats')
      await pg.evaluate("Object.assign(S,{screen:'search',q:'마마',sqDone:false});draw()")
      s=await c('[data-a="brand:마마온"]');J.want('⑨ 검색 자동완성의 브랜드 「마마온」 → 브랜드 화면',(s['screen'],s['brand'])==('brand','마마온'))
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
