import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      brands=await pg.evaluate("allBrands()")
      for br in brands:
        subs=await pg.evaluate("(br)=>{S.brand=br;return bSubs()}",br)
        states=[(False,None,False,None),(True,None,False,None),(False,subs[-1],True,None)]
        if view=='mo': states+=[(False,subs[0],False,'bsort'),(False,None,True,'bfilter')]
        for f,sub,good,sh in states:
          await pg.evaluate("([v,br,f,sub,good,sh])=>{Object.assign(S,{view:v,screen:'brand',brand:br,follow:f?{[br]:true}:{},bsub:sub,bsort:'default',bf:{good,pmin:null,pmax:null},sheet:sh,mega:null,sOpen:false,resetTop:1});draw()}",[view,br,f,sub,good,sh])
          r=await pg.evaluate(CHK);out['n']+=1
          if r['over']:out['over'].append([view,W,br,sub,sh,r['over']])
          for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      for dom in [None,'뷰티','육아용품','주방용품']:
        for intab in ([False,True] if view=='mo' else [False]):
          await pg.evaluate("([v,d,t])=>{Object.assign(S,{view:v,screen:'brands',bdom:d,brandsInTab:t,sheet:null,resetTop:1});draw()}",[view,dom,intab])
          r=await pg.evaluate(CHK);out['n']+=1
          if r['over']:out['over'].append([view,W,'모아보기',dom,r['over']])
          for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
