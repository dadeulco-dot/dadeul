import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
STATES=[{'fav':{},'requested':{},'user':None,'sheet':None},
 {'fav':{},'requested':{},'user':None,'sheet':None,'recent':['p3'],'recentQ':['젖병']},
 {'fav':{'p1':True,'m2':True,'p3':True,'m30':True,'m15':True,'p5':True},'requested':{'썬크림':True,'유모차':True},'user':None,'sheet':None},
 {'fav':{'p1':True,'m2':True,'m10':True,'m12':True,'p2':True,'m3':True},'requested':{},'user':{'ch':'kakao'},'sheet':None},
 {'fav':{'p1':True},'requested':{},'user':None,'sheet':'login'},
 {'fav':{'p1':True},'requested':{},'user':{'ch':'naver'},'sheet':'noti'}]
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for st in STATES:
        await pg.evaluate("([v,st])=>{Object.assign(S,{view:v,screen:'favs',recent:[],recentQ:[],cmp:{},mega:null,sOpen:false,resetTop:1},st);draw()}",[view,st])
        r=await pg.evaluate(CHK);out['n']+=1
        if r['over']:out['over'].append([view,W,list(st['fav'].keys()),st['sheet'],r['over']])
        for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
