import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""찜 탭의 「찜 | 모아 사기」 두 칸 — 결과까지 자동 판정 (HANDOFF.md 6장)
   탭 숫자 = 찜 + 참여 · 두 칸 숫자 · 열린 참여 제품이 있으면 점 · 모아 사기 칸 = 참여한 것 전부, 상태 순서대로 묶음
   · 상세 갔다 뒤로 → 보던 칸 그대로 · 참여 취소가 숫자에 반영 · 모아 사기 탭을 숨기면 찜만"""
import asyncio
from playwright.async_api import async_playwright
ORDER=['지금 살 수 있어요','사람을 모으는 중','브랜드에 제안 중','지난 모아 사기']
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',moaOn:true,screen:'home',fav:{{p1:true,m2:true}},joins:{{d1:true,d2:true,d3:true,d5:true}},favSeg:'fav'}});draw()")
      E=lambda js: pg.evaluate(js)
      async def c(sel,w=150):
        ok=await E(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return ok
      tab='.tab[data-a="favs"]' if view=='mo' else '.gbtn[data-a="favs"]'
      # 모바일은 지금 보고 있는 탭에 동작이 없어 동작 이름으로 못 찾음 → 이름(「찜」)으로 찾음
      cnt=lambda: E("((view)=>{const t=view==='mo'?[...document.querySelectorAll('.tabs .tab')].find(e=>/^찜/.test(e.innerText.trim())):document.querySelector('.gbtn[data-a=\"favs\"]');return ((t||{}).innerText||'').replace(/\\D/g,'')})('"+view+"')")
      J.want('① 탭 숫자 = 찜 2 + 참여 4 = 6',await cnt()=='6',await cnt())
      await c(tab);seg=await E("(document.querySelector('.fseg')||{}).innerText||''")
      J.want('② 두 칸 「찜 2 · 모아 사기 4」 · 열린 참여 제품(하로)이 있어 점',('찜 2' in seg.replace('\n',' ')) and ('모아 사기 4' in seg.replace('\n',' ')) and await E("!!document.querySelector('.fseg .sdot')"),seg.replace('\n',' '))
      await c('[data-a="favseg:moa"]')
      heads=await E("[...document.querySelectorAll('.fgrp .fgh b')].map(e=>e.innerText)");rows=await E("document.querySelectorAll('.mrow2').length")
      J.want('③ 모아 사기 칸 = 참여 4개 전부 · 상태 순서대로 묶음',rows==4 and heads==[h for h in ORDER if h in heads] and len(heads)==4,(rows,heads))
      await c('.mrow2 [data-a="deal:d1"]');J.want('④ 열린 하로 → 모아 사기 상세',await E("[S.screen,S.did]")==['deal','d1'])
      await c('[data-a="dealback"]' if view=='mo' else tab)
      J.want('⑤ 돌아오면 보던 「모아 사기」 칸 그대로',await E("[S.screen,S.favSeg]")==['favs','moa'])
      await c('[data-a="moaleave:d2"]')
      J.want('⑥ 참여 취소 → 줄 3개 · 탭 숫자 5',await E("document.querySelectorAll('.mrow2').length")==3 and await cnt()=='5',await cnt())
      await c('[data-a="favseg:fav"]');await E("S.protoOpen=true;draw()");await c('.pfp [data-a="moaon"]')
      await E("Object.assign(S,{screen:'favs'});draw()")
      J.want('⑦ 모아 사기 탭을 숨기면 두 칸이 사라지고 숫자는 찜만(2)',not await E("!!document.querySelector('.fseg')") and await cnt()=='2',await cnt())
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
