import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
import asyncio,json
from playwright.async_api import async_playwright
CHK="""()=>{const root=document.querySelector('.phone')||document.querySelector('.pcroot');const W=document.documentElement.clientWidth;
 const R=(document.querySelector('.phone')||document.body).getBoundingClientRect();const over=[],orph=[];
 if(document.documentElement.scrollWidth>W+1)over.push('page');
 root.querySelectorAll('*').forEach(el=>{const r=el.getBoundingClientRect();if(r.width>0&&r.right>R.right+1&&!el.closest('.crow,.hs,.proto .row,.ptw,.pproto'))over.push((el.innerText||el.tagName).slice(0,20))});
 root.querySelectorAll('div,span,td').forEach(el=>{if([...el.children].some(c=>['block','flex','table','grid'].includes(getComputedStyle(c).display)))return;
  const t=el.innerText.trim();if(t.length<10||t.includes('\\t'))return;const rg=document.createRange();rg.selectNodeContents(el);
  const L={};[...rg.getClientRects()].filter(r=>r.width>1).forEach(r=>{const k=Math.round(r.top/4);L[k]=(L[k]||0)+r.width});
  const ws=Object.values(L);if(ws.length>1&&ws[ws.length-1]/Math.max(...ws)<.25)orph.push(t.slice(-26))});
 return {over:[...new Set(over)].slice(0,3),orph:[...new Set(orph)]}}"""
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      states=await pg.evaluate("""()=>{const L=[];LSUBS.forEach(s=>{const keys=[...SORTS(s).map(x=>x[0]),...tplOf(s).map(c=>'cat:'+c.k)];
        keys.forEach(k=>L.push({screen:'list',lsub:s,lsort:k,f:{good:false,pmin:null,pmax:null,brands:[]},sheet:null}));
        L.push({screen:'list',lsub:s,lsort:'default',f:{good:true,pmin:30000,pmax:50000,brands:[]},sheet:null});
        L.push({screen:'list',lsub:s,lsort:'default',f:{good:true,pmin:50000,pmax:null,brands:['없는브랜드']},sheet:null});
        ['sort','filter'].forEach(sh=>L.push({screen:'list',lsub:s,lsort:'default',f:{good:false,pmin:null,pmax:null,brands:[]},sheet:sh}))});
       P.forEach(p=>[false,true].forEach(m=>L.push({screen:'detail',pid:p.id,month:m,sheet:null})));return L}""")
      for st in states:
        for cmp in [{},{'p1':1,'m2':1,'m12':1}]:
          await pg.evaluate("([st,v,c])=>{Object.assign(S,st,{view:v,cmp:c,mega:null,resetTop:1});draw()}",[st,view,cmp])
          r=await pg.evaluate(CHK);out['n']+=1
          if r['over']:out['over'].append([view,W,st.get('lsub') or st.get('pid'),st.get('lsort'),r['over']])
          for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph'])
  print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
