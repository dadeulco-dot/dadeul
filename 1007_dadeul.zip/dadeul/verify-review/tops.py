import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
"""운영 콘솔 — 결과까지 자동 판정 (기대값은 docs/moa-buy.md 4 · 7장의 규칙에서 직접 계산 — 프로토타입 함수로 기대값을 만들지 않음)
   후보 묶기 · 대기업 표시 · 인원 기준 순서 막기 · 열기 · 마감(제안 / 첫 단계 미달) · 브랜드 가격 판단 4가지 · 열기 · 끝내기 · 소비자 화면 반영"""
import asyncio,math
from playwright.async_api import async_playwright
def tier_price(C,off):
    t=100 if C<30000 else 500 if C<100000 else 1000
    return math.floor(C*(100-off)/100/t)*t
async def m():
  bad=[]
  def want(label,cond,info=''):
    print(('맞음 ' if cond else '틀림 ✗ ')+label,('→ '+str(info)) if info!='' else '')
    if not cond: bad.append(label)
  async with async_playwright() as pw:
    b=await pw.chromium.launch();pg=await b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300)
    E=lambda js: pg.evaluate(js)
    async def c(sel,w=150):
      ok=await E(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
      if not ok: print('(버튼 없음!)',sel)
      return ok
    await E("S.view='pc';draw();S.protoOpen=true;draw()");await c('.pfp [data-a="console"]')
    tabs=await E("[...document.querySelectorAll('.opsnav button')].map(b=>b.innerText.split('\\n')[0].replace(/\\s*\\d+$/,''))")
    want('① 콘솔 다섯 칸',tabs==['후보','모으는 중','브랜드 답변','열림','지난'],tabs)
    await c('[data-a="opsgroup:sub"]')
    heads=await E("[...document.querySelectorAll('.opsgh b')].map(e=>e.innerText)");subs=await E("[...new Set(opsCands().filter(x=>opsCheck(x).ok).map(x=>x.sub))]")
    want('② 카테고리별로 묶으면 소분류 이름으로',sorted(heads)==sorted(subs),heads)
    await c('[data-a="opsgroup:brand"]');await c('[data-a="opsex"]')
    await c('[data-a="opsbig:도담"]')
    want('④ 브랜드 줄 「대기업 · 계열사로 표시」 → 그 브랜드 제품이 모두 후보에서 빠짐',await E("opsCands().filter(x=>x.brand==='도담').every(x=>!opsCheck(x).ok&&opsCheck(x).checks.some(k=>k[0].startsWith('대기업')&&!k[1]))"))
    await c('[data-a="opsbig:도담"]');await c('[data-a="opsex"]')
    want('⑤ 다시 풀면 대기업 조건이 돌아옴',await E("opsCands().filter(x=>x.brand==='도담').every(x=>opsCheck(x).checks.find(k=>k[0].startsWith('대기업'))[1])"))
    # 인원 기준은 위 단계일수록 많아야 함 — 어기면 열리지 않음
    n0=await E("DEALS.length");await c('[data-a="opsprep:m22"]')
    await pg.fill('[data-ops="tier:m22:0"]','300');await pg.press('[data-ops="tier:m22:0"]','Tab');await pg.wait_for_timeout(150)
    await c('[data-a="opsopen:m22"]')
    want('⑥ 인원 기준이 위 단계에서 줄면 열리지 않음',await E("DEALS.length")==n0 and '위 단계일수록' in (await E("S.toast") or ''),await E("S.toast"))
    await c('[data-a="opsprep:m22"]')
    # 노바 열기 — 단계 미리 보기 가격은 규칙대로
    await c('[data-a="opsprep:m3"]')
    C=await E("itemOf('m3').price");L=await E("opsCheck(itemOf('m3')).low90")
    exp=[f"{o}% {tier_price(C,o):,}원" for o in [20,25,30,35,40]]
    got=await E("[...document.querySelectorAll('.opstier')].map(e=>e.innerText.split('\\n')[0].trim())")
    want('⑦ 단계 미리 보기 가격 = 소비자가 × (1 − 할인율), 눈금 내림',got==exp,(got,exp))
    hid=await E("[...document.querySelectorAll('.opstier.hid')].length");want('⑦ 90일 최저가보다 비싼 단계만 흐리게',hid==sum(1 for o in [20,25,30,35,40] if tier_price(C,o)>L),(hid,L))
    await pg.fill('[data-ops="tier:m3:0"]','60');await pg.press('[data-ops="tier:m3:0"]','Tab');await pg.wait_for_timeout(150)
    await pg.fill('[data-ops="days:m3"]','10');await pg.press('[data-ops="days:m3"]','Tab');await pg.wait_for_timeout(150)
    await c('[data-a="opsopen:m3"]')
    nd=await E("DEALS.find(d=>d.pid==='m3')")
    want('⑧ 열면 모으는 중 · 바꾼 인원 기준 · 모집 마감일(10일 뒤)',bool(nd) and nd['state']=='gathering' and nd['tierN'][0]==60 and nd['until']==await E("opsDays(10)") and nd['n']==0,nd and {k:nd[k] for k in ['state','tierN','until','n']})
    await c('[data-a="opstab:gather"]');await E("dealOf('d2').n=104;draw()")
    await c('[data-a="opsclose:d2"]');want('⑨ 첫 단계(100명)를 넘으면 「마감하고 제안」 → 브랜드 답변으로',await E("dealOf('d2').state")=='proposing')
    await c(f'[data-a="opsclose:{nd["id"]}"]')
    want('⑩ 첫 단계 미달이면 성사 안 됨 · 이유 기록',await E(f"dealOf('{nd['id']}').state")=='failed' and '첫 단계' in (await E(f"dealOf('{nd['id']}').why") or ''))
    await c('[data-a="opstab:propose"]')
    # 브랜드 가격 판단 — 규칙에서 손으로 계산한 기대값 (프로토타입 함수로 만들지 않음)
    # 프리모: 소비자가 27,500 · 도달 20% = 22,000
    for price,expv in [('22000','열어도 됨'),('21500','열어도 됨'),('23000','거절')]:
      await pg.fill('[data-offer="d2"]',price);await pg.wait_for_timeout(100)
      v=(await E("document.querySelector('[data-vd=\"d2\"] .opsv').innerText")).strip();dis=await E("document.querySelector('[data-oo=\"d2\"]').getAttribute('aria-disabled')")
      want(f'⑪ 프리모 {price}원 → {expv}',v==expv and ((dis is None)==(expv=='열어도 됨')),(v,'버튼 '+('비활성' if dis else '활성')))
    # 미리내: 소비자가 38,000 · 320명으로 올려 30% 단계(26,500)에 도달시킴 → 「다시 협상」 경우를 만듦
    await E("dealOf('d3').n=320;draw()")
    # 도달 30% 기준: 28,500(25% · 한 단계)=열어도 됨 · 29,600(22% · 8%p)=다시 협상 · 30,400(20% · 두 단계)=다시 협상 · 30,800(18.9%)=거절
    for price,expv in [('28500','열어도 됨'),('29600','다시 협상'),('30400','다시 협상'),('30800','거절')]:
      await pg.fill('[data-offer="d3"]',price);await pg.wait_for_timeout(100)
      v=(await E("document.querySelector('[data-vd=\"d3\"] .opsv').innerText")).strip();dis=await E("document.querySelector('[data-oo=\"d3\"]').getAttribute('aria-disabled')")
      want(f'⑪ 미리내 {price}원 → {expv}',v==expv and ((dis is None)==(expv=='열어도 됨')),(v,'버튼 '+('비활성' if dis else '활성')))
    await pg.fill('[data-offer="d3"]','29600');await pg.wait_for_timeout(100);await c('[data-a="opsgoopen:d3"]')
    want('⑪ 「다시 협상」 가격으로는 열리지 않음',await E("dealOf('d3').state")=='proposing')
    await pg.fill('[data-offer="d2"]','21500');await pg.wait_for_timeout(100);await c('[data-a="opsgoopen:d2"]')
    d2=await E("({state:dealOf('d2').state,offer:dealOf('d2').offer,buy:canBuy(dealOf('d2'))})")
    want('⑫ 21,500원으로 열기 → 열림 · 확정가 기록 · 누구나 구매',d2=={'state':'open','offer':21500,'buy':True},d2)
    await c('[data-a="opstab:open"]');await c('[data-a="opsend:d13"]')
    want('⑬ 구매 기간 끝내기 → 지난 · 더는 살 수 없음',await E("dealOf('d13').state")=='done' and not await E("canBuy(dealOf('d13'))"))
    await c('[data-a="deal:d2"]')
    box=await E("document.querySelector('.mstat2').innerText")
    want('⑭ 소비자 화면에 바로 반영 — 「다들 제안 22,000원 / 브랜드 확정 21,500원」','22,000원' in box and '21,500원' in box and '브랜드 확정' in box)
    print('오류',errs)
    mo=await b.new_page(viewport={'width':390,'height':844});await mo.goto(URL);await mo.wait_for_timeout(300)
    await mo.evaluate("Object.assign(S,{view:'mo',screen:'console'});draw()")
    want('⑮ 모바일에서는 「PC에서만 열려요」',(await mo.evaluate("document.querySelector('.t-h').innerText")).strip()=='운영 콘솔은 PC에서만 열려요')
    await b.close()
  print('판정 오류',bad)
asyncio.run(m())
