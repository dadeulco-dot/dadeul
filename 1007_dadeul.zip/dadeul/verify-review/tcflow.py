import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""비교 흐름 — 결과까지 자동 판정 (HANDOFF.md 4장 · CLAUDE.md 2-6 · 5장)
   하나만 담으면 비교 못 함 · 같은 소분류 최대 4개 · 「차이 큰 것만」 기본 켜짐(보이는 숫자 5%p 이상) · 보이는 숫자 중 유일한 최고만 굵게
   · 목록에서 왔으면 뒤로 · 모바일은 두 개 골라 봄 · 빼기 · 머리 제품 → 상세 · 상세의 「같은 ○○ N종과 비교」 → 목록(N은 실제 개수)"""
import asyncio,re
from playwright.async_api import async_playwright
ROWS="""()=>[...document.querySelectorAll('.crw,.pcgr')].filter(r=>r.querySelectorAll('.cv.num').length).map(r=>({lab:(r.querySelector('.crl,.pcgl').innerText.split('\\n')[0]),
 v:[...r.querySelectorAll('.cv.num')].map(e=>({p:+e.innerText.replace('%',''),b:+getComputedStyle(e).fontWeight>=700}))}))"""
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'list',lsub:'프라이팬',cmp:{{}},cdiff:true}});draw()")
      E=lambda js: pg.evaluate(js)
      async def c(sel,w=150):
        ok=await E(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return ok
      await c('[data-a="cmp:p1"]');await c('.cgo,.tgo')
      J.want('① 하나만 담고 비교 → 비교 화면으로 가지 않고 하나 더 담으라고 안내',await E("S.screen")=='list' and re.search(r'하나(를)? 더 담',await E("S.toast") or '') is not None,await E("S.toast"))
      await c('[data-a="cmp:m2"]');await c('[data-a="compare:프라이팬"].cgo,[data-a="compare:프라이팬"].tgo')
      J.want('② 둘 담고 비교하기 → 프라이팬 비교',await E("[S.screen,S.csub]")==['compare','프라이팬'])
      J.want('③ 「차이 큰 것만」 기본 켜짐',await E("S.cdiff")==True)
      on=await E(ROWS)
      await c('[data-a="cdiff"]');off=await E(ROWS)
      J.want('③ 끄면 모든 줄 · 켜면 보이는 숫자 차이 5%p 이상인 줄만',
             {r['lab'] for r in on}=={r['lab'] for r in off if max(x['p'] for x in r['v'])-min(x['p'] for x in r['v'])>=5} and len(off)>=len(on),([r['lab'] for r in on],[r['lab'] for r in off]))
      okb=True;why=[]
      for r in off:
        ps=[x['p'] for x in r['v']];hi=max(ps);uniq=ps.count(hi)==1
        for x in r['v']:
          if x['b']!=(uniq and x['p']==hi): okb=False;why.append((r['lab'],ps,[y['b'] for y in r['v']]))
      J.want('④ 보이는 숫자 중 유일한 최고만 굵게 (같으면 아무도 굵게 안 함)',okb,why[:3])
      await c('[data-a="cdiff"]')
      await c('[data-a="cmpback"]' if view=='mo' else '[data-a="list:프라이팬"]')
      J.want('⑤ 목록에서 온 비교함 → 뒤로 → 목록',await E("[S.screen,S.lsub]")==['list','프라이팬'])
      await c('[data-a="cmp:m12"]');await c('[data-a="cmp:p2"]');await c('[data-a="cmp:m3"]')
      J.want('⑥ 같은 소분류는 4개까지 — 5번째는 담기지 않고 안내',sorted(await E("Object.keys(S.cmp)"))==sorted(['p1','m2','m12','p2']) and '4' in (await E("S.toast") or ''),await E("S.toast"))
      await c('[data-a="compare:프라이팬"]')
      if view=='mo':
        await c('[data-a="cpick:m12"]');await c('[data-a="cpick:p2"]')
        pair=await E("S.cpair");J.want('⑦ 모바일은 두 개를 골라 나란히',len(pair)==2 and set(pair)<={'p1','m2','m12','p2'},pair)
        heads=await E("[...document.querySelectorAll('.chead [data-a^=\"open:\"],.cmh [data-a^=\"open:\"]')].map(e=>e.dataset.a.slice(5))")
      await c('[data-a="rmcmp:p2"]')
      J.want('⑧ 빼기',not await E("!!S.cmp.p2") and len(await E("Object.keys(S.cmp)"))==3)
      await c('[data-a="open:p1"]')
      J.want('⑨ 비교표 머리의 제품 → 상세',await E("[S.screen,S.pid]")==['detail','p1'])
      n=await E("allIn('프라이팬').length");btn=await E("(document.querySelector('.bottom .main,.pmainbtn')||{}).innerText||''")
      await c('.bottom .main,.pmainbtn')
      J.want(f'⑩ 상세의 「같은 프라이팬 N종과 비교」 → 목록 · N = 실제 {n}종',f'{n}종' in btn and await E("[S.screen,S.lsub]")==['list','프라이팬'],btn)
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
