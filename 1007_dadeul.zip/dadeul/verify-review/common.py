"""검사 공통 — 프로토타입 위치와 화면 검사식(CHK)

프로토타입 위치는 기본적으로 이 폴더 옆의 prototype-review/index.html 입니다.
다른 파일을 검사하려면 환경 변수 DADEUL_HTML 에 경로를 넣으세요.
"""
import os, pathlib
HERE = pathlib.Path(__file__).resolve().parent
HTML = pathlib.Path(os.environ.get('DADEUL_HTML', HERE.parent / 'prototype-review' / 'index.html')).resolve()
if not HTML.exists():
    raise SystemExit(f'프로토타입을 찾지 못했어요: {HTML}\n  → 이 폴더 옆에 prototype-review/index.html 이 있는지, 또는 DADEUL_HTML 경로를 확인해 주세요.')
URL = HTML.as_uri()
# 화면 한 장을 그린 뒤 돌리는 검사식 — 가로 넘침 · 고아 줄(마지막 줄이 너무 짧은 문단)을 찾음. 원본은 tlist.py
CHK = (HERE / 'tlist.py').read_text(encoding='utf-8').split('CHK="""')[1].split('"""')[0]
