import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""찜 — 결과까지 자동 판정 (HANDOFF.md 6장)
   빈 찜 안내(요청만 있어도) · 요청 취소 · 목록에서 찜 → 소분류별 묶음 · 연결 창 문구 · 연결 수단에 맞는 조사(카카오톡으로 · 네이버로)
   · 알림 설정 4가지 · 「비교함에 담아 비교하기」 → 그 소분류 비교(최대 4) · 찜 풀기"""
import asyncio
from playwright.async_api import async_playwright
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H,ch,exp_ch in [('mo',390,844,'kakao','카카오톡으로'),('pc',1440,900,'naver','네이버로')]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'home',fav:{{}},requested:{{'썬크림':true}},user:null,cmp:{{}},moaOn:false}});draw()")
      E=lambda js: pg.evaluate(js)
      async def c(sel,w=150):
        ok=await E(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return ok
      tab='.tab[data-a="favs"]' if view=='mo' else '.gbtn[data-a="favs"]'
      await c(tab);body=await E("document.body.innerText")
      J.want('① 찜이 없으면 요청만 있어도 「아직 찜한 제품이 없어요」 · 요청 목록도 보임','아직 찜한 제품이 없어요' in body and '썬크림' in body)
      await c('[data-a="unreq:썬크림"]');J.want('② 요청 취소',await E("Object.keys(S.requested).length")==0)
      await E("S.screen='list';S.lsub='프라이팬';draw()")
      for i in ['m2','m3','p1']: await c(f'[data-a="fav:{i}"]')
      J.want('③ 목록에서 찜 3개',sorted(await E("Object.keys(S.fav).filter(k=>S.fav[k])"))==['m2','m3','p1'])
      await c(tab);grp=await E("[...document.querySelectorAll('.fgrp .fgh')].map(e=>e.innerText.replace(/\\s+/g,' ').trim())")
      J.want('④ 찜 화면 = 소분류별 묶음 (프라이팬 3)',any(g.startswith('프라이팬 3') for g in grp),grp)
      await c('[data-a="sheet:login"]')
      J.want('⑤ 알림 받기 → 연결 창 「알림을 받으려면 연결해 주세요」',(await E("document.querySelector('.sheet .t-h').innerText")).strip()=='알림을 받으려면 연결해 주세요')
      await c(f'[data-a="login:{ch}"]')
      nb=await E("document.querySelector('.notib').innerText")
      J.want(f'⑥ 연결 → 「{exp_ch} · …」 (연결 수단에 맞는 조사)',exp_ch in nb and (exp_ch.replace('으로','로') if exp_ch=='카카오톡으로' else '네이버으로') not in nb.replace(exp_ch,''),nb.replace(chr(10),' ')[:60])
      await c('[data-a="sheet:noti"]');n=await E("document.querySelectorAll('.sheet [data-a^=\"notipref:\"]').length")
      J.want('⑦ 알림 설정 4가지',n==4,n)
      await c('[data-a="notipref:label"]');J.want('⑧ 「결과가 바뀌면」 끄기',await E("S.notiPref.label")==False and await E("Object.values(S.notiPref).filter(Boolean).length")==3)
      await c('[data-a="close"]')
      await c('[data-a="favcmp:프라이팬"]')
      cm=sorted(await E("Object.keys(S.cmp)"));exp=sorted(await E("['m2','m3','p1'].filter(i=>!isThin(itemOf(i)))"))
      J.want('⑨ 「비교함에 담아 비교하기」 → 프라이팬 비교 · 찜한 것이 담김',await E("[S.screen,S.csub]")==['compare','프라이팬'] and set(exp)<=set(cm) and len(cm)<=4,(cm,exp))
      await c(tab);await c('.frow [data-a="fav:m3"]')
      J.want('⑩ 찜 풀기 → 목록에서 빠짐',not await E("!!S.fav.m3") and not await E("!!document.querySelector('.frow [data-a=\"open:m3\"]')"))
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
