import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
"""홈 로고 · 홈 탭 — 이미 홈에서 다시 누르면 맨 위로 + 새로고침(다시 섞기), 다른 화면에서 오면 보던 홈 그대로
   라벨 · 정렬 규칙 섹션(제목이 「모아보니 「대체로 만족」인 제품」인 섹션만)은 새로고침해도 그대로 (CLAUDE.md 2-7)
   ※ 「관심 가질 만한 제품」 카드에도 같은 문구가 들어 있어, 제목으로 골라야 함
   판정이 틀리면 「오류」 줄을 남겨 run_all 이 실패로 봄"""
import asyncio
from playwright.async_api import async_playwright
SIG="()=>({seed:SEED,screen:S.screen,top:S.view==='pc'?Math.round(scrollY):Math.round((document.getElementById('scr')||{}).scrollTop||0),rank:(()=>{const sec=[...document.querySelectorAll('section')].find(x=>{const h=x.querySelector('.t-h');return h&&h.innerText.trim().startsWith('모아보니 「대체로 만족」인 제품')});return sec?[...sec.querySelectorAll('[data-a^=\"open:\"]')].map(e=>e.dataset.a).join(','):'(섹션 없음)'})()})"
async def m():
  bad=[]
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'home',fav:{{p1:true,m2:true}},recent:['p3','p1']}});draw()")
      async def scroll(y):
        await pg.evaluate(f"(()=>{{const sc=document.getElementById('scr');if(S.view==='pc')window.scrollTo(0,{y});else sc.scrollTop={y}}})()");await pg.wait_for_timeout(150)
      async def press(sel):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(250)
        return ok
      logo='.top .logo' if view=='mo' else '.gnb .logo'
      def check(label,cond,info): print(view,label,'→',info);(None if cond else bad.append(f'{view} {label}'))
      before=await pg.evaluate(SIG)
      await scroll(1500);ok=await press(logo);after=await pg.evaluate(SIG)
      check('① 홈에서 로고 다시 누름',ok and after['top']==0 and after['seed']!=before['seed'] and after['rank']==before['rank'],
            f"맨 위 {after['top']==0} · 섞기 바뀜 {after['seed']!=before['seed']} · 「대체로 만족」 섹션 그대로 {after['rank']==before['rank']}")
      if view=='mo':
        before=await pg.evaluate(SIG);await scroll(1500);ok=await press('.tab[data-a=\"home\"][aria-current=\"page\"]');after=await pg.evaluate(SIG)
        check('② 홈에서 하단 탭 「홈」 다시 누름',ok and after['top']==0 and after['seed']!=before['seed'],f"버튼 있음 {ok} · 맨 위 {after['top']==0} · 섞기 바뀜 {after['seed']!=before['seed']}")
      for src,sel in [("Object.assign(S,{screen:'list',lsub:'프라이팬'})",'.tab[data-a=\"home\"]' if view=='mo' else logo),("Object.assign(S,{screen:'detail',pid:'p1'})",'.top [data-a=\"home\"]' if view=='mo' else logo)]:
        before=await pg.evaluate(SIG);await pg.evaluate(src+";draw()");await scroll(800);ok=await press(sel);after=await pg.evaluate(SIG)
        check('③ '+('목록' if 'list' in src else '상세')+'에서 홈으로',ok and after['screen']=='home' and after['top']==0 and after['seed']==before['seed'],
              f"홈 {after['screen']=='home'} · 맨 위 {after['top']==0} · 섞기 그대로 {after['seed']==before['seed']}")
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',bad)
asyncio.run(m())
