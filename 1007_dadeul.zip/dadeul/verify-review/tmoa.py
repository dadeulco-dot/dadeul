import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
JS=[{},{'d1':True,'d2':True,'d3':True,'d10':True},{'d7':True,'d12':True,'d13':True,'d10':True}]
CATS=[{'dom':None,'mid':None,'sub':None},{'dom':'주방용품','mid':None,'sub':None},{'dom':'주방용품','mid':'조리팬','sub':None},{'dom':'주방용품','mid':'조리팬','sub':'프라이팬'},{'dom':'육아용품','mid':'수유·이유식 도구','sub':'젖병'}]
MFS=[None,{'states':['gathering'],'pmin':None,'pmax':None,'off':20,'soon':True,'brands':[],'mine':False},{'states':['past'],'pmin':20000,'pmax':40000,'off':0,'soon':False,'brands':['하로'],'mine':False}]
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      states=[];DIDS=await pg.evaluate("DEALS.map(d=>d.id)")
      for j in JS:
        for c in CATS:
          for mf in MFS:
            states.append({'screen':'moa','moaSeg':'live','mcat':c,'mf':mf,'msort':'hot','joins':j,'sheet':None})
        states.append({'screen':'moa','moaSeg':'mine','joins':j,'sheet':None})
        for did in DIDS:
          for pick in [None,'mid']:
            states.append({'screen':'deal','did':did,'joins':j,'pick':pick,'sheet':None})
      for sh in ['moahow','mcats','msort','mfilter']:
        states.append({'screen':'moa','moaSeg':'live','joins':{'d1':True},'sheet':sh})
      for on in [True,False]:
        for pid in ['p1','p5','p3']: states.append({'screen':'detail','pid':pid,'moaOn':on,'sheet':None,'joins':{}})
        states.append({'screen':'home','moaOn':on,'sheet':None,'joins':{}})
      for st in states:
        await pg.evaluate("""([v,st])=>{
          if(st.mf===null)st.mf=MF0();Object.assign(S,{view:v,moaOn:true,user:{ch:'kakao'},mega:null,sOpen:false,resetTop:1,mcat:{dom:null,mid:null,sub:null},mf:MF0()},st);draw()}""",[view,st])
        r=await pg.evaluate(CHK);out['n']+=1
        if r['over']:out['over'].append([view,W,st.get('screen'),st.get('did') or str(st.get('mcat')),r['over']])
        for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
