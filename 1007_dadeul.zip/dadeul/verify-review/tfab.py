import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""프로토타입 「샘플」 버튼 — 결과까지 자동 판정
   어느 폭 · 어느 화면에서도 하단 막대 · 비교함 띠 · 상단 메뉴와 겹치지 않음 · 열기 · 항목을 고르면 그 화면으로 가고 닫힘 · 바깥을 누르면 닫힘"""
import asyncio
from playwright.async_api import async_playwright
OV="""()=>{const f=document.querySelector('.pfb').getBoundingClientRect();const hits=[];
 document.querySelectorAll('.bottom,.tabs,.cfloat,.tray,.gnb').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&!(f.right<=r.left||f.left>=r.right||f.bottom<=r.top||f.top>=r.bottom))hits.push(e.className)});
 return hits}"""
STATES=["S.screen='home'","S.screen='list';S.lsub='프라이팬';S.cmp={}","S.screen='list';S.lsub='프라이팬';S.cmp={p1:1,m2:1}","S.screen='detail';S.pid='p1'","S.screen='compare';S.csub='프라이팬';S.cmp={p1:1,m2:1}","S.screen='cats'","S.screen='moa';S.moaSeg='live'","S.screen='deal';S.did='d1'","S.screen='favs'"]
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',1280,900),('pc',1440,900)]:
      J.tag=f'{view}{W}'
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      over=[]
      for st in STATES:
        await pg.evaluate(f"S.view='{view}';S.moaOn=true;S.protoOpen=false;{st};S.resetTop=1;draw()")
        h=await pg.evaluate(OV)
        if h: over.append((st,h))
      J.want(f'① 화면 {len(STATES)}가지 모두 「샘플」 버튼이 막대 · 띠 · 메뉴와 겹치지 않음',not over,over[:2])
      await pg.evaluate(f"S.view='{view}';S.screen='home';draw()")
      await pg.click('.pfb');await pg.wait_for_timeout(100)
      J.want('② 누르면 열림',await pg.evaluate("S.protoOpen"))
      await pg.click('.pfp [data-a="pick:p3"]');await pg.wait_for_timeout(150)
      J.want('③ 항목(라온랩 상세)을 고르면 그 화면으로 가고 닫힘',await pg.evaluate("S.protoOpen===false&&S.screen==='detail'&&S.pid==='p3'"))
      await pg.click('.pfb');await pg.wait_for_timeout(100)
      box=await pg.evaluate("(()=>{const r=document.querySelector('.pfp').getBoundingClientRect();return [r.right+40,r.top+10]})()")
      await pg.mouse.click(min(box[0],W-10),box[1]);await pg.wait_for_timeout(100)
      J.want('④ 바깥을 누르면 닫힘',await pg.evaluate("S.protoOpen===false"))
      print(J.tag,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
