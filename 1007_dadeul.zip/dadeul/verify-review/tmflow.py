import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
"""모아 사기 흐름 — 결과까지 자동 판정 (기대값은 docs/moa-buy.md · HANDOFF.md 7장의 규칙에서)
   카테고리 좁히기 · 운영자가 바꾼 인원 기준 · 가격 고르기 없음 · 참여 시 연결 창 문구 · 닫으면 보류한 참여 지움
   · 참여 · 취소 인원 · 누구나 구매 · 제안가와 확정가 공개 · 실시간 시간 · 참여자 알림 3종 · 리뷰 상세 한 줄(D-day 없음)"""
import asyncio,re
from playwright.async_api import async_playwright
async def m():
  bad=[]
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'home',user:null,joins:{{}},moaOn:true}});draw()")
      def want(label,cond,info=''):
        print(view,('맞음 ' if cond else '틀림 ✗ ')+label,('→ '+str(info)) if info!='' else '')
        if not cond: bad.append(f'{view} {label}')
      async def c(sel,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return ok
      E=lambda js: pg.evaluate(js)
      await c('.hmoa [data-a="moa"]');want('① 홈 소개 → 모아 사기 탭',await E("S.screen")=='moa')
      await c('[data-a="mdom:육아용품"]')
      doms=await E("mList().map(d=>midOf(dItem(d).sub).dom)");want('② 육아용품을 고르면 육아용품만',len(doms)>0 and set(doms)=={'육아용품'},doms)
      await c('[data-a="mmid:수유·이유식 도구"]');await c('[data-a="msub:젖병"]')
      subs=await E("mList().map(d=>dItem(d).sub)");want('③ 젖병을 고르면 젖병만',len(subs)>0 and set(subs)=={'젖병'},subs)
      await c('[data-a="deal:d9"]')
      rows=await E("[...document.querySelectorAll('.trow')].map(r=>r.innerText.replace(/\\n/g,' '))")
      want('④ 운영자가 바꾼 인원 기준(50 · 100 · 150 · 250 · 400명)이 단계표에 그대로',all(re.search(rf'\b{n}명',r) for n,r in zip([50,100,150,250,400],rows)) and len(rows)==5,rows)
      want('④ 가격을 고르는 버튼이 없음 (참여만)',not await E("!!document.querySelector('[data-a^=\"mpick\"]')"))
      n0=await E("dCount(dealOf('d9'))")
      await c('[data-a="moajoin:d9"]')
      want('⑤ 연결 전 참여 → 연결 창 「참여하시려면 연결해 주세요」',await E("S.sheet")=='login' and (await E("document.querySelector('.sheet .t-h').innerText")).strip()=='참여하시려면 연결해 주세요')
      await c('[data-a="close"]')
      want('⑥ 그냥 닫으면 보류한 참여가 지워지고 참여도 안 됨',await E("S.pendJoin")==None and not await E("!!S.joins.d9"))
      await c('[data-a="moajoin:d9"]');await c('[data-a="login:kakao"]')
      want('⑧ 연결하면 바로 참여되고 인원이 1 늘어남',await E("!!S.joins.d9") and await E("dCount(dealOf('d9'))")==n0+1,(n0,await E("dCount(dealOf('d9'))")))
      await c('[data-a="moaleave:d9"]')
      want('⑨ 참여 취소 → 인원이 원래대로',not await E("!!S.joins.d9") and await E("dCount(dealOf('d9'))")==n0)
      await E("Object.assign(S,{screen:'deal',did:'d10',joins:{}});draw()")
      btn=await E("(document.querySelector('.bottom .main,.dgrid .main')||{}).innerText||''")
      want('⑩ 열린 제품은 참여 안 한 사람도 「브랜드 페이지에서 사기」',btn.startswith('브랜드 페이지에서 사기'),btn)
      box=await E("document.querySelector('.mstat2').innerText")
      want('⑩ 브랜드 가격으로 열리면 제안가 · 확정가를 함께 보여줌',('다들 제안' in box) and ('브랜드 확정' in box))
      t1=await E("document.querySelector('.dday').innerText");await pg.wait_for_timeout(1300);t2=await E("document.querySelector('.dday').innerText")
      want('⑩ 하루 미만이면 실시간으로 줄어듦',re.fullmatch(r'\d\d:\d\d:\d\d 남음',t1) is not None and t1!=t2,(t1,t2))
      await E("S.protoOpen=true;draw()");await c('.pfp [data-a="demoMoa"]')
      ban=await E("(document.querySelector('.buyb')||{}).innerText||''")
      want('⑪ 참여한 제품이 열리면 띠 「참여하신 모아 사기가 열렸어요」','참여하신 모아 사기가 열렸어요' in ban)
      await c('.buyb [data-a="moaseg:mine"]')
      heads=await E("[...document.querySelectorAll('.fgrp .fgh b')].map(e=>e.innerText)")
      rows=await E("document.querySelectorAll('.mrow2').length");joined=await E("Object.keys(S.joins).filter(k=>S.joins[k]).length")
      want('⑫ 내 참여 = 참여한 것 전부, 상태별 묶음 · 맨 앞은 「지금 살 수 있어요」',rows==joined and heads[:1]==['지금 살 수 있어요'],(rows,joined,heads))
      await E("Object.assign(S,{screen:'noti'});draw()")
      notes=await E("notiList().filter(n=>n.kind==='모아 사기').map(n=>n.id.replace('n-moa-','')+':'+n.t)")
      exp=await E("DEALS.filter(d=>myJoin(d)&&(canBuy(d)||d.state==='failed')).map(d=>d.id)")
      ok=len(notes)==len(exp) and all(any(n.startswith(i+':') for n in notes) for i in exp)
      t={n.split(':')[0]:n for n in notes}
      ok=ok and ('제시해 그 가격으로 열었어요' in t.get('d10','')) and ('에 열렸어요' in t.get('d1','')) and ('성사되지 않았어요' in t.get('d5',''))
      want('⑬ 참여자 알림 3종 (열림 · 브랜드 가격으로 열림 · 성사 안 됨) — 참여한 열림 · 실패 제품에만',ok,notes)
      await E("Object.assign(S,{screen:'detail',pid:'p1'});draw()")
      line=await E("(document.querySelector('.moaline')||{}).innerText||''")
      want('⑭ 리뷰 상세 맨 아래 한 줄 「…에 열렸어요」 · 리뷰 화면이라 D-day 없음','에 열렸어요' in line and not await E("!!document.querySelector('.moaline .dday')"),line)
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',bad)
asyncio.run(m())
