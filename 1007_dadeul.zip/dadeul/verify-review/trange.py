import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge,RAW_JS,bounds
"""가격 범위 막대 — 결과까지 자동 판정 (HANDOFF.md 4장)
   양 끝 = 그 소분류 최저 · 최고가(1,000원 단위) · 끌면 1,000원 단위 · 오른쪽 손잡이는 왼쪽을 못 넘음(최소 1,000원 간격)
   · 끝에 몰린 왼쪽 손잡이를 다시 잡을 수 있음 · 키보드 ← 한 번에 1,000원 · 범위 밖 제품은 안 보임 · 초기화"""
import asyncio
from playwright.async_api import async_playwright
async def drag(pg,sel,frac):
  box=await pg.evaluate(f"""()=>{{const i=document.querySelector('{sel}'),r=i.getBoundingClientRect(),lo=+i.min,hi=+i.max,v=+i.value;
    return {{x:r.left+14+(r.width-28)*(v-lo)/(hi-lo),y:r.top+r.height/2,l:r.left+14,w:r.width-28}}}}""")
  await pg.mouse.move(box['x'],box['y']);await pg.mouse.down()
  await pg.mouse.move(box['l']+box['w']*frac,box['y'],steps=8);await pg.mouse.up();await pg.wait_for_timeout(200)
ST="({pmin:S.f.pmin,pmax:S.f.pmax,lo:+document.querySelector('.rng').dataset.lo,hi:+document.querySelector('.rng').dataset.hi})"
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'list',lsub:'프라이팬',f:{{good:false,pmin:null,pmax:null,brands:[]}},sheet:{'\"filter\"' if view=='mo' else 'null'},resetTop:1}});draw()")
      raw=await pg.evaluate(RAW_JS,'프라이팬');lo,hi=bounds([x['price'] for x in raw])
      s=await pg.evaluate(ST);J.want('① 막대 양 끝 = 프라이팬 최저 · 최고가 (1,000원 단위)',(s['lo'],s['hi'])==(lo,hi),(s['lo'],s['hi'],lo,hi))
      await drag(pg,'.rng input[data-r="a"]',0.3);s=await pg.evaluate(ST)
      J.want('② 왼쪽 손잡이를 30%로 → 1,000원 단위 · 그 근처 값',s['pmin']%1000==0 and abs(s['pmin']-(lo+(hi-lo)*.3))<=2000,s)
      await drag(pg,'.rng input[data-r="b"]',0.7);s=await pg.evaluate(ST)
      J.want('③ 오른쪽 손잡이를 70%로',s['pmax']%1000==0 and abs(s['pmax']-(lo+(hi-lo)*.7))<=2000,s)
      await drag(pg,'.rng input[data-r="b"]',0.05);s=await pg.evaluate(ST)
      J.want('④ 오른쪽 손잡이는 왼쪽을 넘지 못함 (최소 1,000원 간격)',s['pmax']==s['pmin']+1000,s)
      if view=='mo': await pg.evaluate("document.querySelector('.sheet .main').click()");await pg.wait_for_timeout(150)
      shown=await pg.evaluate("[...new Set([...document.querySelectorAll('.lcard [data-a^=\"open:\"],.ltable [data-a^=\"open:\"]')].map(e=>e.dataset.a.slice(5)))]")
      prices={x['id']:x['price'] for x in raw}
      J.want('⑤ 범위 밖 제품은 안 보임',all(s['pmin']<=prices[i]<=s['pmax'] for i in shown),[(i,prices[i]) for i in shown])
      if view=='mo': await pg.evaluate("S.sheet='filter';draw()");await pg.wait_for_timeout(150)
      await pg.evaluate("S.f.pmin=null;S.f.pmax=null;S.keepTop=1;draw()")
      await drag(pg,'.rng input[data-r="a"]',1.0);s1=await pg.evaluate(ST)
      await drag(pg,'.rng input[data-r="a"]',0.5);s2=await pg.evaluate(ST)
      J.want('⑥ 끝까지 민 왼쪽 손잡이를 다시 잡아 50%로',s1['pmin'] is not None and s1['pmin']>=hi-1000 and abs(s2['pmin']-(lo+(hi-lo)*.5))<=2000,(s1['pmin'],s2['pmin']))
      await pg.evaluate("S.f.pmin=null;S.f.pmax=null;S.keepTop=1;draw()")
      await pg.focus('.rng input[data-r="b"]');await pg.keyboard.press('ArrowLeft');await pg.keyboard.press('ArrowLeft');await pg.wait_for_timeout(150);s=await pg.evaluate(ST)
      J.want('⑦ 키보드 ← 두 번 → 최고가에서 2,000원',s['pmax']==hi-2000,s)
      await pg.evaluate("document.querySelector('[data-a=\"freset\"]').click()");await pg.wait_for_timeout(100);s=await pg.evaluate(ST)
      J.want('⑧ 초기화 → 제한 없음',s['pmin'] is None and s['pmax'] is None,s)
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
