import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
JS=[{},{'d1':True,'d10':True,'d2':True,'d3':True,'d5':True,'d4':True},{'d6':True}]
FV=[{},{'p1':True,'m2':True,'p3':True}]
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for on in [True,False]:
        for seg in ['fav','moa']:
          for j in JS:
            for f in FV:
              await pg.evaluate("([v,on,seg,j,f])=>{Object.assign(S,{view:v,moaOn:on,screen:'favs',favSeg:seg,joins:j,fav:f,sheet:null,mega:null,resetTop:1});draw()}",[view,on,seg,j,f])
              r=await pg.evaluate(CHK);out['n']+=1
              if r['over']:out['over'].append([view,W,on,seg,list(j),r['over']])
              for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
        for j in JS:
          await pg.evaluate("([v,j])=>{Object.assign(S,{view:v,moaOn:true,screen:'moa',moaSeg:'mine',joins:j,sheet:null,resetTop:1});draw()}",[view,j])
          r=await pg.evaluate(CHK);out['n']+=1
          if r['over']:out['over'].append([view,W,'moa-mine',list(j),r['over']])
          for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
