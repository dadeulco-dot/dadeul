import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900),('pc',1920,1080)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for dom in ['뷰티','육아용품','주방용품']:
        for q in ['','크림','ㅅㅋ','xyz']:
          for rec in [[],['프라이팬','크림','편수냄비']]:
            if view=='mo':
              await pg.evaluate("([dom,q,rec])=>{Object.assign(S,{view:'mo',screen:'cats',cdom:dom,cq:q,recentSubs:rec,prev:null,sheet:null,crTop:0,resetTop:1});draw()}",[dom,q,rec])
            else:
              await pg.evaluate("([dom,q,rec])=>{Object.assign(S,{view:'pc',screen:'list',lsub:'프라이팬',mega:dom,cq:q,recentSubs:rec,sheet:null,resetTop:1});draw()}",[dom,q,rec])
            r=await pg.evaluate(CHK);out['n']+=1
            if r['over']:out['over'].append([view,W,dom,q,r['over']])
            for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
