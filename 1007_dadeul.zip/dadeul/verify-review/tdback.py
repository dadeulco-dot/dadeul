import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
"""상세 뒤로 가기 — 들어오기 전 화면으로 (목록이면 정렬 · 필터 그대로). 이전 화면이 없으면 그 제품의 목록 (HANDOFF.md 1장)
   결과까지 자동 판정 — 틀리면 「판정 오류」"""
import asyncio
from playwright.async_api import async_playwright
async def m():
  bad=[]
  def want(label,cond,info):
    print(('맞음 ' if cond else '틀림 ✗ ')+label,'→',info)
    if not cond: bad.append(label)
  async with async_playwright() as pw:
    b=await pw.chromium.launch();pg=await b.new_page(viewport={'width':390,'height':844});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300)
    ST="({screen:S.screen,lsub:S.lsub,lsort:S.lsort,good:!!(S.f&&S.f.good),q:S.q,sqDone:S.sqDone,brand:S.brand,csub:S.csub})"
    async def run(setup,open_sel,label,expect):
      await pg.evaluate(f"S.view='mo';S.dPrev=null;{setup};S.resetTop=1;draw()")
      ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{open_sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(120)
      mid=await pg.evaluate("S.screen")
      await pg.evaluate("document.querySelector('[data-a=\"dback\"]').click()");await pg.wait_for_timeout(120)
      r=await pg.evaluate(ST)
      miss=[k for k,v in expect.items() if r.get(k)!=v]
      want(label,ok and mid=='detail' and not miss,f"상세로 {mid=='detail'} · 돌아온 곳 {r['screen']}"+(f" · 다른 값 {[(k,r.get(k),expect[k]) for k in miss]}" if miss else ''))
    await run("Object.assign(S,{screen:'list',lsub:'프라이팬',lsort:'cat:coat',f:{good:true,pmin:null,pmax:null,brands:[]}})","[data-a=\"open:p1\"]","목록(정렬 · 필터 걸림) → 상세 → 뒤로",{'screen':'list','lsub':'프라이팬','lsort':'cat:coat','good':True})
    await run("Object.assign(S,{screen:'home',fav:{p1:true},recent:['p3']})","[data-a=\"open:p1\"]","홈 → 상세 → 뒤로",{'screen':'home'})
    await run("Object.assign(S,{screen:'search',q:'프라이팬',sqDone:true})","[data-a=\"open:p1\"]","검색 결과 → 상세 → 뒤로",{'screen':'search','q':'프라이팬','sqDone':True})
    await run("Object.assign(S,{screen:'favs',fav:{p3:true},favSeg:'fav'})","[data-a=\"open:p3\"]","찜 → 상세 → 뒤로",{'screen':'favs'})
    await run("Object.assign(S,{screen:'brand',brand:'하로'})","[data-a=\"open:p1\"]","브랜드 → 상세 → 뒤로",{'screen':'brand','brand':'하로'})
    await run("Object.assign(S,{screen:'compare',csub:'프라이팬',cmp:{p1:1,m2:1},cpair:[]})","[data-a=\"open:p1\"]","비교함 → 상세 → 뒤로",{'screen':'compare','csub':'프라이팬'})
    await pg.evaluate("Object.assign(S,{screen:'detail',pid:'p3',dPrev:null});draw();document.querySelector('[data-a=\"dback\"]').click()");await pg.wait_for_timeout(120)
    r=await pg.evaluate(ST);sub=await pg.evaluate("byId('p3').sub")
    want('이전 화면 없이 바로 연 상세 → 뒤로 = 그 제품의 목록',r['screen']=='list' and r['lsub']==sub,f"{r['screen']} · {r['lsub']} (기대 {sub})")
    print('JS 오류',errs);await b.close()
  print('판정 오류',bad)
asyncio.run(m())
