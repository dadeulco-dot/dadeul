import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge,label,RAW_JS
"""맞춤 노출 — 결과까지 자동 판정 (CLAUDE.md 2-7 · HANDOFF.md 5장)
   처음 온 사람: 맞춤 칸 없음 · 「이렇게 써요」 있음 / 검색으로 온 사람: 「「아기 젖병」 찾아 오셨죠?」 · 육아용품으로 열림
   / 다시 온 사람: 「최근 보신 ○○과 비슷한 제품」 · 그 대분류 · 「이렇게 써요」 없음
   · 맞춤 추천은 「대체로 만족」만(원자료 계산) · 같은 화면을 다시 그려도 그대로 · 새로고침하면 맞춤 칸만 바뀌고 늘 같은 칸은 그대로
   · 맞춤 끄기 · 직접 고른 대분류가 우선"""
import asyncio
from playwright.async_api import async_playwright
# 「이렇게 써요」는 제목 있는 칸이 아니라 띠(.steps) — 제목으로 찾으면 늘 없다고 나옴
SNAP="""()=>{const sec=t=>[...document.querySelectorAll('section')].find(s=>{const h=s.querySelector('.t-h');return h&&h.innerText.trim().startsWith(t)});
 const ids=s=>s?[...new Set([...s.querySelectorAll('[data-a^="open:"]')].map(e=>e.dataset.a.slice(5)))]:null;
 const fy=document.querySelector('.fysec');
 return {dom:S.hdom||null,openDom:homeParts().dom,fyTitle:fy?(fy.querySelector('.t-h')||{}).innerText.trim():null,fy:ids(fy),why:(document.querySelector('.why2')||{}).innerText||'',
  steps:!!document.querySelector('.steps'),rank:ids(sec('모아보니 「대체로 만족」인 제품')),gaps:ids(sec('별점만 보면 놓치는 이야기')),pair:ids(sec('나란히 보면 달라요')),
  tc:[...document.querySelectorAll('.tcard')].map(e=>e.innerText.split('\\n')[0]).join('·'),guide:(sec('「')||{innerText:''}).innerText.slice(0,80),filt:(document.querySelector('.fcard,.filtcard')||{innerText:''}).innerText.slice(0,60)}}"""
async def m():
  J=Judge('mo')
  async with async_playwright() as pw:
    b=await pw.chromium.launch();pg=await b.new_page(viewport={'width':390,'height':844});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300);await pg.evaluate("S.view='mo';draw()")
    raw={}
    for sub in ['크림','젖병','프라이팬','편수냄비']:
      for x in await pg.evaluate(RAW_JS,sub): raw[x['id']]=x
    good=lambda ids: all(label(raw[i]['n'],raw[i]['evalN'],raw[i]['probN'])=='대체로 만족' for i in ids)
    domOf=lambda sub: {'크림':'뷰티','젖병':'육아용품','프라이팬':'주방용품','편수냄비':'주방용품'}[sub]
    async def via(a):
      await pg.evaluate("S.protoOpen=true;draw()")
      if not await pg.evaluate(f"(()=>{{const e=document.querySelector('.pfp [data-a=\"{a}\"]');if(!e)return false;e.click();return true}})()"): print('(버튼 없음!)',a)
      await pg.wait_for_timeout(150)
      return await pg.evaluate(SNAP)
    r=await via('demoFirst')
    J.want('① 처음 온 사람: 맞춤 칸 없음 · 「이렇게 써요」 있음',r['fy'] is None and r['steps'],(r['fyTitle'],r['steps']))
    r=await via('demoEntry')
    J.want('② 검색으로 온 사람: 「「아기 젖병」 찾아 오셨죠?」 · 육아용품으로 열림 · 이유를 사실대로',
           r['fyTitle'] is not None and '아기 젖병' in r['fyTitle'] and r['openDom']=='육아용품' and '아기 젖병' in r['why'],(r['fyTitle'],r['openDom'],r['why'][:40]))
    J.want('② 맞춤 추천은 「대체로 만족」만',bool(r['fy']) and good(r['fy']),r['fy'])
    r1=await via('demo1')
    top=await pg.evaluate("topSubs(interest())[0]")
    J.want('③ 다시 온 사람: 「최근 보신 ○○과 비슷한 제품」 · 그 대분류 · 「이렇게 써요」 없음',
           r1['fyTitle'] is not None and r1['fyTitle'].startswith('최근 보신') and r1['openDom']==domOf(top) and not r1['steps'],(r1['fyTitle'],r1['openDom'],top))
    J.want('③ 맞춤 추천은 「대체로 만족」만',bool(r1['fy']) and good(r1['fy']),r1['fy'])
    await pg.evaluate("S.keepTop=1;draw()");await pg.wait_for_timeout(100);r1b=await pg.evaluate(SNAP)
    J.want('④ 같은 화면을 다시 그리면 그대로',all(r1b[k]==r1[k] for k in ['fy','gaps','pair','tc','rank']))
    combos=set();fixed=True;allgood=True
    for i in range(6):
      await pg.evaluate("S.protoOpen=true;draw()");await pg.evaluate("document.querySelector('.pfp [data-a=\"reseed\"]').click()");await pg.wait_for_timeout(80)
      r=await pg.evaluate(SNAP);combos.add((tuple(r['fy'] or []),tuple(r['gaps'] or []),tuple(r['pair'] or []),r['tc']))
      fixed=fixed and r['rank']==r1['rank'] and r['guide']==r1['guide'] and r['openDom']==r1['openDom']
      allgood=allgood and good(r['fy'] or [])
    J.want('⑤ 새로고침 6번 → 맞춤 칸이 바뀜 (2가지 이상)',len(combos)>=2,len(combos))
    J.want('⑤ 늘 같은 칸(「대체로 만족」 순위 · 구매 가이드)과 대분류는 그대로',fixed)
    J.want('⑤ 몇 번을 섞어도 맞춤 추천은 「대체로 만족」만',allgood)
    await pg.evaluate("document.querySelector('[data-a=\"poff\"]').click()");await pg.wait_for_timeout(100);r=await pg.evaluate(SNAP)
    J.want('⑥ 맞춤 끄기 → 맞춤 칸이 사라지고 「맞춤을 껐어요」로 사실대로 알림',r['fy'] is None and '맞춤을 껐어요' in r['why'],(r['fyTitle'],r['why'][:30]))
    await pg.evaluate("document.querySelector('[data-a=\"poff\"]').click()");await pg.wait_for_timeout(100)
    await pg.evaluate("document.querySelector('[data-a=\"hdom:육아용품\"]').click()");await pg.wait_for_timeout(100);r=await pg.evaluate(SNAP)
    rsub=await pg.evaluate("rankSub()")
    J.want('⑦ 직접 고른 대분류가 우선 → 육아용품 · 순위 칸도 육아용품의 소분류',r['openDom']=='육아용품' and domOf(rsub)=='육아용품',(r['openDom'],rsub))
    r=await via('demoFirst')
    J.want('⑧ 다시 온 사람을 본 뒤 「처음 온 사람」 → 기록이 비워져 처음 온 사람 화면',r['fy'] is None and r['steps'],(r['fyTitle'],r['steps']))
    print('JS 오류',errs);await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
