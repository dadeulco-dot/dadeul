import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import label,RAW_JS,Judge
"""소분류 목록 — 결과까지 자동 판정 (기대값은 원자료에서 HANDOFF.md 4장 규칙대로 직접 계산)
   「무엇이 가장 중요하세요?」 기준 = 그 카테고리 30건 이상 중 좋다 비율 높은 순 · 다시 누르면 풀림 · 표본 부족은 늘 맨 뒤
   · 담기 · 상세 없는 샘플 · 상세 · 경로 · 「대체로 만족」만 + 가격 범위 · 풀기 · 단위 가격 정렬은 용량 있는 소분류만"""
import asyncio
from playwright.async_api import async_playwright
ORDER="(()=>{const a=[...document.querySelectorAll('.lcard [data-a^=\"open:\"],.ltable [data-a^=\"open:\"]')].map(e=>e.dataset.a.slice(5));return [...new Set(a)]})()"
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'list',lsub:'프라이팬',lsort:'default',f:{{good:false,pmin:null,pmax:null,brands:[]}},cmp:{{}}}});draw()")
      raw={x['id']:x for x in await pg.evaluate(RAW_JS,'프라이팬')}
      thin={i for i,x in raw.items() if x['n']<30}
      async def c(sel,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return ok
      await c('[data-a="kcat:coat"]')
      order=await pg.evaluate(ORDER)
      elig=[i for i,x in raw.items() if i not in thin and x['cs'].get('coat',[0,0])[0]>=30]
      best=max(raw[i]['cs']['coat'][1]/raw[i]['cs']['coat'][0] for i in elig)
      tops={i for i in elig if abs(raw[i]['cs']['coat'][1]/raw[i]['cs']['coat'][0]-best)<1e-9}
      J.want('① 「코팅·표면 내구성」 기준 → 맨 위는 30건 이상 중 좋다 비율이 가장 높은 제품',order[:1] and order[0] in tops,(order[:1],sorted(tops)))
      sh=[raw[i]['cs']['coat'][1]/raw[i]['cs']['coat'][0] for i in order if i in elig]
      J.want('① 30건 이상인 제품끼리는 좋다 비율 높은 순',all(sh[k]>=sh[k+1]-1e-9 for k in range(len(sh)-1)))
      J.want('① 표본 부족 제품은 맨 뒤',all(i in thin for i in order[len(order)-len(thin):]) and len(order)==len(raw),(order[-len(thin):] if thin else []))
      await c('[data-a="kcat:coat"]')
      J.want('② 같은 기준을 다시 누르면 풀림',await pg.evaluate("S.lsort")=='default')
      await c('[data-a="cmp:m2"]');await c('[data-a="cmp:m3"]')
      J.want('③ 목록에서 비교함에 담기',set(await pg.evaluate("Object.keys(S.cmp)"))=={'m2','m3'})
      await c('[data-a="open:m2"]')
      J.want('④ 상세가 없는 샘플은 목록에 머무르고 안내',await pg.evaluate("S.screen")=='list' and '상세' in (await pg.evaluate("S.toast") or ''),await pg.evaluate("S.toast"))
      await c('[data-a="open:p1"]')
      J.want('⑤ 하로 → 상세',await pg.evaluate("[S.screen,S.pid]")==['detail','p1'])
      await c('[data-a="list:프라이팬"]')
      J.want('⑥ 경로 「프라이팬」 → 목록',await pg.evaluate("[S.screen,S.lsub]")==['list','프라이팬'])
      if view=='mo': await c('[data-a="sheet:filter"]')
      await c('[data-a="fgood"]');await pg.evaluate("S.f.pmin=30000;S.f.pmax=50000;S.keepTop=1;draw()")
      if view=='mo': await c('.sheet .main')
      shown=set(await pg.evaluate(ORDER))
      exp={i for i,x in raw.items() if label(x['n'],x['evalN'],x['probN'])=='대체로 만족' and 30000<=x['price']<=50000}
      J.want('⑦ 「대체로 만족」만 + 3만~5만 원 → 조건에 맞는 제품만 빠짐없이',shown==exp,(sorted(shown),sorted(exp)))
      await c('[data-a="freset"]')
      J.want('⑧ 필터 풀기 → 전부',await pg.evaluate("[S.f.good,S.f.pmin,S.f.pmax]")==[False,None,None] and set(await pg.evaluate(ORDER))==set(raw))
      for sub,expect in [('크림',True),('프라이팬',False)]:
        await pg.evaluate(f"Object.assign(S,{{screen:'list',lsub:'{sub}',sheet:null}});draw()")
        if view=='mo': await c('[data-a="sheet:sort"]')
        txt=await pg.evaluate("(document.querySelector('.sheet')||document.querySelector('.lsel[data-change=\"lsort\"]')||document.body).innerText")
        J.want(f'⑨ 「단위 가격 낮은 순」은 용량이 있는 소분류에만 — {sub}',('단위 가격' in txt)==expect)
        if view=='mo': await pg.evaluate("S.sheet=null;draw()")
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
