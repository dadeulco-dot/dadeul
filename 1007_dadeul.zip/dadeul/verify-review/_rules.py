"""판정형 검사 공통 — 원자료에서 규칙대로 직접 계산 (프로토타입의 계산 함수를 쓰지 않음)"""
import math
def label(n,evalN,probN):
    if n<30: return '표본 부족'
    r=probN/evalN if evalN else 0
    return '대체로 만족' if r<.15 else '의견 갈림' if r<.35 else '대체로 불만'
RAW_JS="""(sub)=>allIn(sub).map(x=>{const f=x.full?byId(x.id):null;
 const cs={};if(f)f.cats.forEach(c=>{if(!c.defect)cs[c.k]=[c.m,c.g]});else Object.assign(cs,x.cs||{});
 return {id:x.id,name:x.name,brand:x.brand,price:x.price,n:x.n,evalN:x.evalN,probN:x.probN,cs,vol:!!x.vol}})"""
def bounds(prices,step=1000):
    return math.floor(min(prices)/step)*step, math.ceil(max(prices)/step)*step
def pct(g,m): return round(g/m*100)
class Judge:
    def __init__(self,tag=''): self.bad=[];self.tag=tag
    def want(self,label,cond,info=''):
        print(self.tag,('맞음 ' if cond else '틀림 ✗ ')+label,('→ '+str(info)) if info!='' else '')
        if not cond: self.bad.append(f'{self.tag} {label}'.strip())
