import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge,RAW_JS,pct
"""이 이야기만 자세히 — 결과까지 자동 판정 (*빅데이터 후 재설계 예정 · 지금 화면 기준*)
   카테고리 제목 · 한 달 써 본 분만 스위치 · 뒤로 → 상세의 그 카테고리 위치 · 같은 소분류 비교 막대는 좋다 비율 높은 순(원자료 계산)
   · 지금 제품 강조 · 이 기준으로 목록 보기 → 그 정렬"""
import asyncio
from playwright.async_api import async_playwright
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'detail',pid:'p3',month:false,resetTop:1}});draw()")
      E=lambda js,*a: pg.evaluate(js,*a)
      async def c(sel,w=200):
        ok=await E(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return ok
      await c('#c-absorb [data-a="story:absorb"]')
      title=(await E("document.querySelector('h1.t-title').innerText")).strip()
      J.want('① 「흡수·끈적임」 자세히 → 이야기 화면 · 제목',await E("[S.screen,S.storyK]")==['story','absorb'] and title.endswith('흡수·끈적임'),title)
      raw=await E(RAW_JS,'크림');elig=[x for x in raw if x['n']>=30 and x['cs'].get('absorb',[0,0])[0]>=30]
      exp=[pct(x['cs']['absorb'][1],x['cs']['absorb'][0]) for x in sorted(elig,key=lambda x:-x['cs']['absorb'][1]/x['cs']['absorb'][0])]
      got=await E("[...document.querySelectorAll('.prow .pv')].map(e=>+e.innerText.replace('%',''))")
      J.want('② 같은 크림끼리 비교 막대 = 좋다 비율 높은 순 (원자료 계산과 같음)',got==exp,(got,exp))
      me=await E("(document.querySelector('.prow.me')||{}).innerText||''")
      J.want('② 지금 제품(라온랩)이 강조됨','라온랩' in me,me.replace(chr(10),' '))
      await c('[data-a="month"]');J.want('③ 한 달 써 본 분만 켜기',await E("S.month")==True)
      await c('[data-a="storyback"]')
      top=await E("Math.round(document.getElementById('c-absorb').getBoundingClientRect().top)")
      J.want('④ 뒤로 → 상세의 그 카테고리 위치',await E("[S.screen,S.pid]")==['detail','p3'] and 0<=top<260,top)
      await E("S.month=false;draw()");await c('#c-moist [data-a="story:moist"]')
      J.want('⑤ 「보습·유지력」 자세히',await E("S.storyK")=='moist')
      await c('[data-a="theme:크림:moist"]')
      J.want('⑥ 이 기준으로 목록 보기 → 크림 목록 · 보습 기준 정렬',await E("[S.screen,S.lsub,S.lsort]")==['list','크림','cat:moist'])
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
