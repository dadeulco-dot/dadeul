import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK.replace('.ptw,','.ptw,.opsw,')
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for W,H in [(1024,768),(1280,800),(1440,900),(1920,1080)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for st in [{'opsTab':'cand','opsGroup':'brand','opsEx':False,'opsOpen':None},{'opsTab':'cand','opsGroup':'sub','opsEx':True,'opsOpen':None},
                 {'opsTab':'cand','opsGroup':'brand','opsEx':True,'opsOpen':'m3','opsBig':{'무이':True}},{'opsTab':'gather'},{'opsTab':'propose'},{'opsTab':'open'},{'opsTab':'past'}]:
        await pg.evaluate("(st)=>{Object.assign(S,{view:'pc',screen:'console',opsBig:{}},st);draw()}",st)
        r=await pg.evaluate(CHK);out['n']+=1
        if r['over']:out['over'].append([W,st['opsTab'],r['over']])
        for o in r['orph']:out['orph'].add(f'{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
