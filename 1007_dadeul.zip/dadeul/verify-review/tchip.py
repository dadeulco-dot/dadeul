import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""상세의 후기 카테고리 칩 줄 — 결과까지 자동 판정
   처음엔 왼쪽 화살표 숨김 · 오른쪽 화살표 → 줄이 넘어가고 왼쪽 화살표가 생김 · 왼쪽 화살표 → 처음으로
   · 잘린 칩을 누르면 그 칩이 줄 안에 다 보임 · 본문을 넘기면 지금 읽는 카테고리 칩이 따라 켜지고 다 보임 · 다시 그려도 줄 위치 유지"""
import asyncio
from playwright.async_api import async_playwright
ST="""()=>{const r=document.getElementById('crow'),rr=r.getBoundingClientRect();const on=document.querySelector('.crow .chip.on');const o=on&&on.getBoundingClientRect();
 return {x:Math.round(r.scrollLeft),L:document.querySelector('.carr.l').classList.contains('show'),R:document.querySelector('.carr.r').classList.contains('show'),
  on:on?(on.dataset.a||'').replace('go:',''):null,full:on?(o.left>=rr.left-1&&o.right<=rr.right+1):null}}"""
async def run(pg,view,J):
  await pg.evaluate(f"S.view='{view}';S.screen='detail';S.pid='p1';S.act=null;S.crowXs={{}};S.resetTop=1;draw()");await pg.wait_for_timeout(200)
  if view=='mo':
    await pg.evaluate("const sc=document.getElementById('scr');sc.scrollTop=document.getElementById('c-coat').offsetTop-110");await pg.wait_for_timeout(700)
  s0=await pg.evaluate(ST);J.want('① 처음엔 맨 앞 · 왼쪽 화살표 숨김',s0['x']==0 and not s0['L'],s0)
  await pg.evaluate("(document.querySelector('.carr.r.show button')||{click(){}}).click()");await pg.wait_for_timeout(600);s1=await pg.evaluate(ST)   # 숨은 화살표는 누를 수 없음 → 멈추지 않고 판정
  J.want('② 오른쪽 화살표 → 줄이 넘어가고 왼쪽 화살표가 생김',s1['x']>0 and s1['L'],s1)
  await pg.evaluate("(document.querySelector('.carr.l.show button')||{click(){}}).click()");await pg.wait_for_timeout(600);s2=await pg.evaluate(ST)
  J.want('③ 왼쪽 화살표 → 처음으로',s2['x']==0,s2)
  await pg.evaluate("document.querySelector('[data-a=\"go:exp\"]').click()");await pg.wait_for_timeout(1200);s3=await pg.evaluate(ST)
  J.want('④ 반쯤 잘린 마지막 칩(구매 경험)을 누르면 그 칩이 켜지고 줄 안에 다 보임',s3['on']=='exp' and s3['full'],s3)
  if view=='pc': await pg.evaluate("window.scrollTo(0,document.getElementById('c-heat').getBoundingClientRect().top+scrollY-175)")
  else: await pg.evaluate("const sc=document.getElementById('scr');sc.scrollTop=document.getElementById('c-heat').offsetTop-100")
  await pg.wait_for_timeout(900);s4=await pg.evaluate(ST)
  J.want('⑤ 본문을 「열 전달」로 넘기면 그 칩이 따라 켜지고 다 보임',s4['on']=='heat' and s4['full'],s4)
  await pg.evaluate("document.querySelector('[data-a=\"go:defect\"]').click()");await pg.wait_for_timeout(1200)
  x1=(await pg.evaluate(ST))['x']
  await pg.evaluate("document.querySelector('[data-a=\"month\"]').click()");await pg.wait_for_timeout(300)
  x2=(await pg.evaluate(ST))['x']
  J.want('⑥ 다시 그려도(한 달 써 본 분만 스위치) 칩 줄 위치 유지',abs(x1-x2)<=2,(x1,x2))
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('pc',1440,900),('mo',390,844)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await run(pg,view,J);print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
