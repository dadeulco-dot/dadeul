import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""알림 — 결과까지 자동 판정 (HANDOFF.md 6장)
   종 표시 숫자 = 안 읽은 알림 수 · 알림을 누르면 제품 · 브랜드 · 검색으로 가고 읽음 · 뒤로 → 알림 · 모두 읽음 → 표시 사라짐
   · 연결 전 안내 → 연결 후 「네이버로도 받고 있어요」"""
import asyncio
from playwright.async_api import async_playwright
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'home',fav:{{p1:true,m2:true,m15:true}},requested:{{'유모차':true}},follow:{{'마마온':true}},readNoti:{{}},user:null,moaOn:false}});draw()")
      E=lambda js: pg.evaluate(js)
      async def c(sel,w=150):
        ok=await E(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return ok
      badge=lambda: E("((document.querySelector('.bell .bdot,.gbtn[data-a=\"noti\"] .bdot')||{}).innerText||'').trim()")
      await c('[data-a="noti"]')
      items=await E("document.querySelectorAll('.nitem').length");unread=await E("document.querySelectorAll('.nitem.unread').length")
      J.want('① 종 → 알림 · 처음엔 모두 안 읽음',await E("S.screen")=='noti' and items>0 and unread==items,(items,unread))
      await E("S.screen='home';draw()");b0=await badge();await c('[data-a="noti"]')
      J.want('② 종 표시 숫자 = 안 읽은 알림 수',b0==str(unread),(b0,unread))
      for nid,expect,back,label in [('n-p1',"S.screen==='detail'&&S.pid==='p1'",'[data-a="dback"]' if view=='mo' else '[data-a="noti"]','찜 소식 → 그 제품 상세'),
                                    ('n-br-마마온',"S.screen==='brand'&&S.brand==='마마온'",'[data-a="brandback"],.bback','브랜드 알림 → 그 브랜드'),
                                    ('n-req-유모차',"S.screen==='search'&&S.q==='유모차'&&S.sqDone",'[data-a="sback"]' if view=='mo' else '[data-a="noti"]','요청 알림 → 그 검색어 결과')]:
        await c(f'[data-a="nopen:{nid}"]');went=await E(expect)
        await c(back);back_ok=await E("S.screen")=='noti'
        isread=await E(f"!document.querySelector('.nitem.unread[data-a=\"nopen:{nid}\"]')")
        J.want(f'③ {label} · 읽음 처리 · 뒤로 → 알림',went and back_ok and isread,(went,back_ok,isread))
      left=await E("document.querySelectorAll('.nitem.unread').length")
      J.want('④ 연 알림만큼 안 읽음이 줄어듦',left==unread-3,(unread,left))
      await c('[data-a="notiread"]');await E("S.screen='home';draw()")
      J.want('⑤ 모두 읽음 → 종의 숫자 사라짐',await badge()=='',await badge())
      await c('[data-a="noti"]')
      J.want('⑥ 연결 전에는 「지금은 다들 안에서만 보여드려요」','지금은 다들 안에서만 보여드려요' in await E("document.body.innerText"))
      await c('[data-a="sheet:login"]');await c('[data-a="login:naver"]')
      J.want('⑦ 연결하면 「네이버로도 받고 있어요」','네이버로도 받고 있어요' in await E("document.body.innerText"))
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
