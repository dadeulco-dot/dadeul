"""다들 프로토타입 검사 — 한 번에 모두 돌리기

    python run_all.py              # 전부 (약 4~5분)
    python run_all.py tmoa tops    # 고른 것만 (이름에서 .py 는 빼고)

하나라도 실패하면 마지막 줄이 「실패」이고 종료 코드가 1입니다.
"""
import sys, os, re, json, subprocess, shutil, time, pathlib
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from common import HTML

# (파일, 무엇을 보나) — 화면 검사: 여러 폭 · 여러 상태를 그려 「JS 오류 · 가로 넘침 · 고아 줄」을 셈
RENDER = [
    ('tlist',   '소분류 목록 · 제품 상세 (정렬 · 필터 · 한 달 써 본 분만)'),
    ('tcmp',    '비교함 (2~4개 · 차이 큰 것만)'),
    ('thome',   '홈 (처음 온 사람 · 다시 온 사람 · 검색으로 온 사람)'),
    ('tcatr',   '카테고리 메뉴'),
    ('tsearch', '검색 (입력 전 · 자동완성 · 결과 · 결과 없음)'),
    ('tfavs',   '찜'),
    ('tfavmoa', '찜 탭의 「찜 | 모아 사기」 두 칸'),
    ('tnoti',   '알림'),
    ('tbrand',  '브랜드 · 브랜드 모아보기'),
    ('tstory',  '이 이야기만 자세히'),
    ('tmoa',    '모아 사기 (탭 · 상세 · 내 참여 · 창)'),
    ('topsr',   '운영 콘솔 (PC 다섯 칸)'),
]
# 흐름 검사: 실제로 버튼을 눌러 화면이 의도대로 바뀌는지
FLOW = [   # 모두 결과까지 자동 판정 — 기대값은 확정된 규칙 · 원자료에서 직접 계산 (_rules.py)
    ('tflow',   '목록 — 기준 정렬(30건 이상 · 좋다 비율) · 표본 부족 맨 뒤 · 담기 · 필터 · 단위 가격'),
    ('tcflow',  '비교 — 하나만은 안 됨 · 4개까지 · 차이 큰 것만 · 보이는 숫자 중 유일한 최고만 굵게 · 뒤로'),
    ('tchip',   '상세 칩 줄 — 화살표 · 잘린 칩 · 본문 따라 켜짐 · 다시 그려도 위치 유지'),
    ('trange',  '가격 막대 — 양 끝 · 1,000원 단위 · 못 넘음 · 다시 잡기 · 키보드 · 범위 밖 숨김'),
    ('tcats',   '카테고리 메뉴 — 따라가는 표시 · 초성 · 다른 표기 · 경로로 열고 닫기 · 최근 본 것'),
    ('tfab',    '「샘플」 버튼 — 4개 폭 × 9개 화면 겹침 없음 · 열기 · 고르기 · 바깥 닫기'),
    ('tpers',   '맞춤 — 처음 · 검색 · 다시 온 사람 · 「대체로 만족」만 · 새로고침 · 끄기 · 직접 고른 대분류'),
    ('tsflow',  '검색 — 초성 · 그 소분류만 · 결과 없음 → 요청 · 최근 검색 · N종 카드 · 맞춤 신호 · PC 펼침'),
    ('tfflow',  '찜 — 빈 찜 · 요청 · 소분류 묶음 · 연결 창 · 조사 · 알림 설정 · 비교함에 담아 비교'),
    ('tstflow', '이 이야기만 자세히 — 제목 · 비교 막대 순서 · 지금 제품 강조 · 뒤로 위치 · 그 기준 목록'),
    ('tbflow',  '브랜드 — 묶음 · 브랜드 평가 없음 · 새 제품 알림 · 뒤로 · 초성 이동(머리에 안 가림) · 안내가 사라져도 스크롤 유지'),
    ('tnflow',  '알림 — 종 숫자 · 눌러서 가는 곳 · 읽음 · 뒤로 · 모두 읽음 · 연결 문구'),
    ('tdback',  '상세 뒤로 가기 7가지 경로 — 정렬 · 필터 · 검색어까지'),
    ('tmflow',  '모아 사기 — 카테고리 · 인원 기준 · 참여 · 연결 · 누구나 구매 · 실시간 시간 · 알림'),
    ('tfmflow', '찜 탭 「찜 | 모아 사기」 — 탭 숫자 · 점 · 상태 순서 · 보던 칸 유지 · 취소 · 탭 숨김'),
    ('tops',    '운영 콘솔 — 후보 · 열기 · 마감 · 브랜드 가격 판단 7가지 · 열림 · 소비자 화면 반영'),
    ('thomere', '홈 로고 · 홈 탭 다시 누름 = 맨 위로 + 새로고침 · 다른 화면에서 오면 그대로'),
    ('tdata',   '데이터 정합성 — 후기 숫자 · 모아 사기 규칙'),
]

def syntax_check():
    """프로토타입 안의 스크립트 문법 — node 가 있을 때만"""
    node = shutil.which('node')
    if not node:
        return None, 'node 가 없어 건너뜀 (설치하면 함께 검사)'
    src = HTML.read_text(encoding='utf-8')
    m = re.search(r'<script>\n(.*)\n</script>', src, re.S)
    if not m:
        return False, '스크립트 부분을 찾지 못함'
    tmp = HERE / '_syntax_check.js'
    tmp.write_text(m.group(1), encoding='utf-8')
    r = subprocess.run([node, '--check', str(tmp)], capture_output=True, text=True)
    tmp.unlink(missing_ok=True)
    return r.returncode == 0, (r.stderr.strip().splitlines() or ['문법 이상 없음'])[0][:200]

LOGS = HERE / 'logs'

def run(name):
    t0 = time.time()
    r = subprocess.run([sys.executable, str(HERE / f'{name}.py')], capture_output=True, cwd=HERE, timeout=1800)
    out = (r.stdout + r.stderr).decode('utf-8', 'replace')
    LOGS.mkdir(exist_ok=True)
    (LOGS / f'{name}.txt').write_text(out, encoding='utf-8')   # 흐름 검사는 화면이 의도대로 바뀌었는지를 여기서 사람이 확인
    return out, r.returncode, time.time() - t0

def judge_render(out, code):
    try:
        d = json.loads(out[out.index('{'):out.rindex('}') + 1])
    except Exception:
        return False, 0, '결과를 읽지 못함: ' + out.strip().splitlines()[-1][:160] if out.strip() else '출력 없음'
    bad = []
    if d.get('err'):  bad.append(f"JS 오류 {len(d['err'])}건: {d['err'][0][:100]}")
    if d.get('over'): bad.append(f"가로 넘침 {len(d['over'])}건: {str(d['over'][0])[:100]}")
    if d.get('orph'): bad.append(f"고아 줄 {len(d['orph'])}건: {d['orph'][0][:100]}")
    return (code == 0 and not bad), d.get('n', 0), (' · '.join(bad) or '이상 없음')

def judge_flow(out, code):
    bad = [l.strip() for l in out.splitlines()
           if 'Error' in l or 'Traceback' in l or '버튼 없음' in l or ('오류' in l and '[]' not in l)]
    return (code == 0 and not bad), (bad[0][:180] if bad else '이상 없음')

def main():
    pick = [a.replace('.py', '') for a in sys.argv[1:]]
    render = [x for x in RENDER if not pick or x[0] in pick]
    flow = [x for x in FLOW if not pick or x[0] in pick]
    print(f'검사 대상: {HTML}\n')
    ok_all = True
    ok, msg = syntax_check()
    print(f"[문법]   {'통과' if ok else ('건너뜀' if ok is None else '실패')}  {msg}")
    if ok is False: ok_all = False
    total = 0
    print('\n[화면 검사] 여러 폭 · 여러 상태를 그려 JS 오류 · 가로 넘침 · 고아 줄을 셈')
    for name, desc in render:
        out, code, sec = run(name)
        ok, n, msg = judge_render(out, code)
        total += n; ok_all &= ok
        print(f"  {'통과' if ok else '실패'}  {name:8s} {n:5d}개 상태  {sec:5.0f}초  {desc}" + ('' if ok else f'\n        → {msg}'))
    print('\n[흐름 · 데이터 검사] 실제로 눌러 보고, 숫자가 서로 맞는지')
    for name, desc in flow:
        out, code, sec = run(name)
        ok, msg = judge_flow(out, code)
        ok_all &= ok
        print(f"  {'통과' if ok else '실패'}  {name:8s}  {sec:5.0f}초  {desc}" + ('' if ok else f'\n        → {msg}'))
    print(f"\n화면 상태 {total:,}개 · 흐름 · 데이터 {len(flow)}종 · 검사별 전체 기록: {LOGS}")
    print('결과: 모두 통과' if ok_all else '결과: 실패 — 위의 「실패」 줄을 확인해 주세요')
    sys.exit(0 if ok_all else 1)

if __name__ == '__main__':
    main()
