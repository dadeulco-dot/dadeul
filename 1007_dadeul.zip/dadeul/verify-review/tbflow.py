import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""브랜드 — 결과까지 자동 판정 (CLAUDE.md 2-6 · HANDOFF.md 1장)
   상세의 브랜드 이름 → 브랜드 화면 · 묶음 = 그 브랜드 제품의 소분류(원자료 그대로) · 브랜드 평점 · 브랜드 라벨 없음
   · 새 제품 알림 · 뒤로 (상세 ↔ 브랜드 ↔ 모아보기) · 초성 이동 · 검색 자동완성의 브랜드 → 브랜드 화면"""
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,brand:S.brand,pid:S.pid,follow:Object.keys(S.follow).filter(k=>S.follow[k]),groups:[...document.querySelectorAll('.bgrp .fgh b')].map(e=>e.innerText.trim())})"
async def m():
  J=Judge()
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      J.tag=view
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'detail',pid:'p2',follow:{{}},resetTop:1}});draw()")
      async def c(sel,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        if not ok: print(view,'(버튼 없음!)',sel)
        return await pg.evaluate(ST)
      s=await c('.blink')
      expg=await pg.evaluate("[...new Set(ALL().filter(x=>x.brand==='무이').map(x=>x.sub))]")
      J.want('① 상세의 브랜드 「무이」 → 브랜드 화면 · 묶음 = 무이 제품의 소분류',s['screen']=='brand' and s['brand']=='무이' and sorted(s['groups'])==sorted(expg),(s['groups'],expg))
      body=await pg.evaluate("document.body.innerText")   # 화면 전체 (PC 는 첫 .wrap 이 상단 메뉴라 본문을 못 읽었음)
      J.want('② 브랜드 평점 · 브랜드 라벨 없음 (라벨은 제품마다)','평점' not in body and '브랜드 라벨' not in body and '다들은 브랜드를 평가하지 않아요' in body)
      s=await c('[data-a="follow:무이"]');J.want('③ 새 제품 알림 켜기',s['follow']==['무이'])
      s=await c('[data-a="brandback"]');J.want('④ 뒤로 → 원래 상세',(s['screen'],s['pid'])==('detail','p2'))
      if view=='mo': await pg.evaluate("S.screen='cats';S.prev=null;draw()");s=await c('[data-a="brands"]')
      else: await c('[data-a="mega:뷰티"]');s=await c('.mega [data-a="brands"]')
      J.want('⑤ 브랜드로 찾기 → 모아보기',s['screen']=='brands')
      hb=await pg.evaluate("Math.round((document.querySelector('.gnb')||document.querySelector('.top')).getBoundingClientRect().bottom)")
      bad=[]
      for k in await pg.evaluate("[...document.querySelectorAll('[data-a^=\"bjump:\"]')].map(e=>e.dataset.a.slice(6))"):
        await pg.evaluate(f"document.querySelector('[data-a=\"bjump:{k}\"]').click()");await pg.wait_for_timeout(900)
        t=await pg.evaluate(f"Math.round(document.getElementById('bk-{k}').getBoundingClientRect().top)")
        if not (hb-1<=t<=hb+40): bad.append((k,t))
      J.want('⑥ 초성마다 그 묶음이 상단 머리 바로 아래로 (가려지지 않음 · 마지막 「ㅎ」 포함)',not bad,(hb,bad))
      # 안내(토스트)가 사라지는 순간에 하던 스크롤이 끊기지 않아야 함 — 예전엔 사라질 때 화면 전체를 다시 그려 멈췄음
      await pg.evaluate("say('시험용 안내')");await pg.wait_for_timeout(2000)
      await pg.evaluate("document.querySelector('[data-a=\"bjump:ㅂ\"]').click()");await pg.wait_for_timeout(1200)
      t=await pg.evaluate("Math.round(document.getElementById('bk-ㅂ').getBoundingClientRect().top)")
      J.want('⑥-2 안내가 사라지는 순간의 초성 이동도 끝까지 (스크롤이 끊기지 않음)',hb-1<=t<=hb+40 and await pg.evaluate("!document.querySelector('.toast')"),(hb,t))
      s=await c('[data-a="brand:하로"]');J.want('⑦ 하로 → 브랜드 화면',(s['screen'],s['brand'])==('brand','하로'))
      s=await c('[data-a="brandback"]');J.want('⑧ 뒤로 → 모아보기 (들어온 곳)',s['screen']=='brands')
      await pg.evaluate("Object.assign(S,{screen:'search',q:'마마',sqDone:false});draw()")
      s=await c('[data-a="brand:마마온"]');J.want('⑨ 검색 자동완성의 브랜드 「마마온」 → 브랜드 화면',(s['screen'],s['brand'])==('brand','마마온'))
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
