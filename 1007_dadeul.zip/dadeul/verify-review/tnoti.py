import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
STATES=[{'fav':{},'requested':{},'follow':{},'user':None,'readNoti':{}},
 {'fav':{'p1':True,'m2':True,'p3':True,'m30':True,'m15':True,'m13':True},'requested':{'유모차':True,'썬크림':True},'follow':{'무이':True,'마마온':True},'user':None,'readNoti':{}},
 {'fav':{'p1':True,'m2':True},'requested':{},'follow':{'하로':True},'user':{'ch':'kakao'},'readNoti':{'n-p1':True}}]
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for st in STATES:
        for scr in ['noti','home']:
          await pg.evaluate("([v,st,scr])=>{Object.assign(S,{view:v,screen:scr,sheet:null,mega:null,sOpen:false,resetTop:1},st);draw()}",[view,st,scr])
          r=await pg.evaluate(CHK);out['n']+=1
          if r['over']:out['over'].append([view,W,scr,r['over']])
          for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
