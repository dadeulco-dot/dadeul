import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
QS=['','프라이팬','ㅍㄹㅇ','인덕션 프라이팬','건성 크림','하로','썬크림','xyz 청소기','아기 젖병']
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for q in QS:
        for done in [False,True]:
          for rq in [[],['프라이팬','크림 추천','하로']]:
            if view=='pc' and not done:
              st="([q,rq])=>{Object.assign(S,{view:'pc',screen:'home',q,sqDone:false,sOpen:true,recentQ:rq,requested:{},mega:null,resetTop:1});draw()}"
            else:
              st="([q,rq,v,d])=>{Object.assign(S,{view:v,screen:'search',q,sqDone:d,sOpen:false,recentQ:rq,requested:q==='썬크림'?{'썬크림':true}:{},mega:null,resetTop:1});draw()}"
            await pg.evaluate(st,[q,rq,view,done])
            r=await pg.evaluate(CHK);out['n']+=1
            if r['over']:out['over'].append([view,W,q,done,r['over']])
            for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
