import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
SETS=[{},{'p1':1},{'p1':1,'m2':1},{'p1':1,'m2':1,'m12':1},{'p1':1,'m2':1,'m12':1,'p2':1},{'p1':1,'m15':1},{'p3':1,'m21':1,'m22':1,'m6':1},{'p1':1,'m2':1,'p3':1,'m22':1,'p4':1,'m8':1},{'p5':1,'m30':1,'m33':1}]
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900),('pc',1920,1080)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for c in SETS:
        subs=await pg.evaluate("(c)=>{S.cmp=c;return cmpSubs()}",c) or ['프라이팬']
        for sub in subs:
          for d in [True,False]:
            await pg.evaluate("([v,sub,d])=>{Object.assign(S,{view:v,screen:'compare',csub:sub,cpair:[],cdiff:d,sheet:null,mega:null,resetTop:1});draw()}",[view,sub,d])
            r=await pg.evaluate(CHK);out['n']+=1
            if r['over']:out['over'].append([view,W,list(c.keys()),sub,d,r['over']])
            for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
