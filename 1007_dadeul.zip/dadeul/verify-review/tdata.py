import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
"""데이터 정합성 — 샘플 숫자와 모아 사기 규칙이 서로 맞는지
   ① validateAll(): 찾은 = 모은 + 제외 등 후기 숫자 (프로토타입의 「샘플 · 확인 필요」와 같은 검사)
   ② 모아 사기: 「대체로 만족」만 · 가격 여지(단계 2개+) · 단계 가격 ≤ 90일 최저가 · 표시 할인율 ≤ 실제
                · 제안 · 열림 · 지난은 첫 단계를 넘었어야 함 · 브랜드 가격은 보호선 안 · 인원 기준은 위로 갈수록 많음"""
import asyncio
from playwright.async_api import async_playwright
JS="""()=>{const bad=[...validateAll()];
 DEALS.forEach(d=>{const x=dItem(d),ts=tiersOf(d),id=d.id+' '+x.brand;
  if(labOf(x)!=='대체로 만족')bad.push(id+': 「대체로 만족」이 아님');
  if(!priceRoom(d))bad.push(id+': 가격 여지 없음(남는 단계 2개 미만)');
  ts.forEach(t=>{if(t.p>d.low90)bad.push(id+': '+t.off+'% 단계가 90일 최저가보다 비쌈');if(Math.round((1-t.p/x.price)*1000)/10<t.off)bad.push(id+': '+t.off+'% 표시가 실제 할인보다 큼')});
  for(let i=1;i<ts.length;i++)if(ts[i].need<=ts[i-1].need)bad.push(id+': 인원 기준이 위 단계에서 줄어듦');
  if(['proposing','open','done'].includes(d.state)&&!dReached(d))bad.push(id+': 첫 단계를 못 넘었는데 '+d.state);
  if(d.offer&&!guardOk(d,d.offer))bad.push(id+': 브랜드 가격이 보호선 밖');
  if(d.state==='open'&&!d.saleEnd)bad.push(id+': 열렸는데 구매 종료일이 없음')});
 return {n:DEALS.length,bad}}"""
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch();pg=await b.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300)
    r=await pg.evaluate(JS)
    print('후기 · 모아 사기 데이터 확인 — 모아 사기',r['n'],'개')
    print('데이터 오류',r['bad'])
    print('JS 오류',errs)
    await b.close()
asyncio.run(m())
