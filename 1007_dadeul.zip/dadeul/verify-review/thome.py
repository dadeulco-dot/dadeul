import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio,json
from playwright.async_api import async_playwright
CHK=_CHK
async def main():
  out={'err':[],'over':[],'orph':set(),'n':0}
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo',430,932),('pc',1024,768),('pc',1440,900),('pc',1920,1080)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      for dom in ['뷰티','육아용품','주방용품']:
        for ret in [False,True,'entry']:
          for sh in [None,'method']:
            await pg.evaluate("([v,dom,ret,sh])=>{Object.assign(S,{view:v,screen:'home',hdom:dom,hdomSet:ret!==true,sheet:sh,mega:null,resetTop:1,fav:ret===true?{p1:true,m2:true,p3:true,m5:true}:{},recent:ret===true?['p3','p1','p2','p4']:[],entry:ret==='entry'?{kw:'아기 젖병'}:null});draw()}",[view,dom,ret,sh])
            r=await pg.evaluate(CHK);out['n']+=1
            if r['over']:out['over'].append([view,W,dom,ret,r['over']])
            for o in r['orph']:out['orph'].add(f'{view}{W}: …{o}')
      out['err']+=errs;await pg.close()
    await b.close()
  out['orph']=sorted(out['orph']);print(json.dumps(out,ensure_ascii=False,indent=1))
asyncio.run(main())
