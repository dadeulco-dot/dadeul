import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL
from _rules import Judge
"""카테고리 메뉴 — 결과까지 자동 판정 (HANDOFF.md 1장 · CLAUDE.md 2-2 카테고리)
   두 칸 메뉴(왼쪽 중분류 표시가 오른쪽 위치를 따라감) · 이름 찾기(초성 · 다른 표기) · 경로 → 그 중분류 위치로 열림 · 닫으면 원래 화면
   · 목록 뒤로 → 그 중분류 위치 · 최근 본 카테고리 · PC 펼침 메뉴(Esc 비움 · 바깥 누르면 닫힘)"""
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,cdom:S.cdom,rail:((document.querySelector('.crail .on')||{}).innerText||'').trim()||null,prev:S.prev&&S.prev.screen,cq:S.cq,mega:S.mega,lsub:S.lsub,pid:S.pid,res:[...document.querySelectorAll('[data-cres]:not([hidden]) [data-a^=\"list:\"],[data-cres]:not([hidden]) .crow2')].map(e=>e.innerText.split('\\n')[0].trim())})"
async def m():
  J=Judge('mo')
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    pg=await b.new_page(viewport={'width':390,'height':844});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300);await pg.evaluate("S.view='mo';draw()")
    async def c(sel,wait=250):
      ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(wait)
      if not ok: print('mo (버튼 없음!)',sel)
      return await pg.evaluate(ST)
    s=await c('.tab[data-a="cats:"]');J.want('① 카테고리 탭',s['screen']=='cats')
    s=await c('[data-a="cdom:주방용품"]');J.want('② 대분류 주방용품',s['cdom']=='주방용품')
    s=await c('[data-a="cjump:주방가전"]',800);J.want('③ 왼쪽 「주방가전」 → 그 위치 · 왼쪽 표시 주방가전',s['rail']=='주방가전',s['rail'])
    await pg.evaluate("const cr=document.getElementById('cr');cr.scrollTop=cr.querySelector('[data-g=\"보관용기\"]').offsetTop-cr.offsetTop+20");await pg.wait_for_timeout(400)
    s=await pg.evaluate(ST);J.want('④ 오른쪽을 보관용기까지 넘기면 왼쪽 표시가 따라감',s['rail']=='보관용기',s['rail'])
    s=await c('[data-a="cdom:뷰티"]');J.want('⑤ 뷰티로',s['cdom']=='뷰티')
    await pg.fill('[data-cq]','ㅅㅋ');await pg.wait_for_timeout(150);s=await pg.evaluate(ST)
    J.want('⑥ 초성 「ㅅㅋ」 → 선크림',any('선크림' in r for r in s['res']),s['res'][:6])
    await pg.fill('[data-cq]','크림');await pg.wait_for_timeout(150);s=await pg.evaluate(ST)
    J.want('⑦ 「크림」 → 크림이 들어간 소분류만',len(s['res'])>0 and all('크림' in r for r in s['res']),s['res'][:8])
    s=await c('[data-cres] [data-a="list:크림"]');J.want('⑧ 결과의 크림 → 크림 목록',(s['screen'],s['lsub'])==('list','크림'))
    s=await c('[data-a="catsx:스킨케어"]');J.want('⑨ 목록 경로 「스킨케어」 → 메뉴가 스킨케어 위치로',s['screen']=='cats' and s['rail']=='스킨케어' and s['prev']=='list',(s['rail'],s['prev']))
    s=await c('[data-a="catclose"]');J.want('⑩ 닫기 → 원래 목록',(s['screen'],s['lsub'])==('list','크림'))
    s=await c('[data-a="open:p3"]');s=await c('[data-a="catsx:스킨케어"]')
    J.want('⑪ 상세 경로 「스킨케어」 → 메뉴',s['screen']=='cats' and s['rail']=='스킨케어')
    s=await c('[data-a="catclose"]');J.want('⑫ 닫기 → 원래 상세',(s['screen'],s['pid'])==('detail','p3'))
    await c('[data-a="list:크림"]');s=await c('.top .ib')
    J.want('⑬ 목록에서 뒤로 → 카테고리 (그 중분류 위치)',s['screen']=='cats' and s['rail']=='스킨케어',s['rail'])
    chips=await pg.evaluate("[...document.querySelectorAll('.fchips .chip')].map(e=>e.innerText.trim())")
    J.want('⑭ 최근 본 카테고리에 크림',any('크림'==x or x.startswith('크림') for x in chips),chips)
    print('mo JS 오류',errs);await pg.close()
    J.tag='pc'
    pg=await b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300);await pg.evaluate("S.view='pc';S.screen='list';S.lsub='크림';draw()")
    async def cp(sel,wait=200):
      ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(wait)
      if not ok: print('pc (버튼 없음!)',sel)
      return await pg.evaluate(ST)
    s=await cp('.pcrumb [data-a="mega:뷰티"]');J.want('① 경로 「뷰티」 → 펼침 메뉴',s['mega']=='뷰티')
    await pg.fill('[data-cq]','ㅍㄹㅇ');await pg.wait_for_timeout(150);s=await pg.evaluate(ST);J.want('② 초성 「ㅍㄹㅇ」 → 프라이팬',any('프라이팬' in r for r in s['res']),s['res'][:5])
    await pg.keyboard.press('Escape');await pg.wait_for_timeout(100);s=await pg.evaluate(ST);J.want('③ Esc → 입력 비움 (메뉴는 그대로)',s['cq']=='' and s['mega']=='뷰티',(s['cq'],s['mega']))
    await pg.fill('[data-cq]','후라이팬');await pg.wait_for_timeout(150);s=await pg.evaluate(ST)
    J.want('④ 다른 표기 「후라이팬」 → 프라이팬',any('프라이팬' in r for r in s['res']),s['res'][:5])
    s=await cp('[data-cres] [data-a="list:프라이팬"]');J.want('⑤ 프라이팬 목록',(s['screen'],s['lsub'])==('list','프라이팬'))
    s=await cp('[data-a="mega:주방용품"]');chips=await pg.evaluate("[...document.querySelectorAll('.mega .fchips .chip')].map(e=>e.innerText.trim())")
    J.want('⑥ 펼침 메뉴의 최근 본 카테고리 = 프라이팬 · 크림',{'프라이팬','크림'}<=set(chips),chips)
    await pg.mouse.click(700,850);await pg.wait_for_timeout(150);s=await pg.evaluate(ST);J.want('⑦ 메뉴 밖을 누르면 닫힘',s['mega'] is None)
    print('pc JS 오류',errs);await b.close()
  print('판정 오류',J.bad)
asyncio.run(m())
