"""
다들 · 제미나이 추출 결과 검증 + 정확도 측정
────────────────────────────────────────────────────────
두 가지 일을 한다.

1) validate(comments, result)
   제미나이 출력을 믿기 전에 거른다. 파이프라인에 반드시 넣는다.

2) evaluate(golden_csv, result_json)
   정답셋과 대조해 정확도를 잰다. 매월 1회 돌린다.

사용
   python eval_runner.py validate comments.json result.json
   python eval_runner.py evaluate golden_set.csv result.json
"""

import csv, json, re, sys
from collections import Counter

ISSUES = {"코팅박리","바닥변형","손잡이문제","무게부담","세척불편",
          "변색녹","AS불만","내구성","기능미흡"}
MERITS = {"열효율","눌어붙지않음","가벼움","내구성좋음","세척편함",
          "디자인","가격만족","AS만족"}
SKIPS  = {"협찬","사용 전","제품 무관","내용 없음","판단 불가"}
SENTS  = {"긍정","부정","중립"}

NUM_RE = re.compile(r"\d|한|두|세|네|다섯|여섯|일곱|여덟|아홉|열|반")


# ── 1. 검증 ────────────────────────────────────────────
def validate(comments, result):
    """comments: {id: 원문} / result: 제미나이 출력 리스트
    반환: (통과한 항목, 폐기 사유 목록)"""
    ok, bad = [], []

    if len(result) != len(comments):
        return [], [("전체", f"건수 불일치: 입력 {len(comments)} vs 출력 {len(result)} → 재요청 필요")]

    for r in result:
        rid = r.get("id")
        why = None

        if rid not in comments:
            why = "입력에 없는 id"
        elif r.get("issues") and not set(r["issues"]) <= ISSUES:
            why = f"정의 밖 issues: {set(r['issues']) - ISSUES}"
        elif r.get("merits") and not set(r["merits"]) <= MERITS:
            why = f"정의 밖 merits: {set(r['merits']) - MERITS}"
        elif r.get("skip_reason") and r["skip_reason"] not in SKIPS:
            why = f"정의 밖 skip_reason: {r['skip_reason']}"
        elif r.get("sentiment") not in SENTS:
            why = f"정의 밖 sentiment: {r.get('sentiment')}"
        else:
            m = r.get("months")
            if m is not None:
                if not (0.5 <= m <= 240):
                    why = f"기간 범위 벗어남: {m}"
                # ★ 환각 차단 — 원문에 수량 표현이 없는데 기간이 나왔다면 폐기
                elif not NUM_RE.search(comments[rid]):
                    why = f"원문에 기간 표현이 없는데 months={m}"

        if why:
            bad.append((rid, why))
        else:
            ok.append(r)

    return ok, bad


# ── 2. 정확도 측정 ─────────────────────────────────────
def evaluate(golden_path, result_path):
    """golden_set.csv 형식
       id,text,use,months,issues,sentiment
       issues는 | 로 구분"""
    gold = {int(r["id"]): r for r in csv.DictReader(open(golden_path, encoding="utf-8-sig"))}
    pred = {r["id"]: r for r in json.load(open(result_path, encoding="utf-8"))}

    n = 0
    use_tp = use_fp = use_fn = 0
    mon_ok = mon_n = 0
    iss_ok = iss_n = 0
    sent_ok = 0

    for i, g in gold.items():
        p = pred.get(i)
        if not p:
            continue
        n += 1

        g_use = g["use"].strip().lower() in ("1","true","y","사용")
        p_use = bool(p["use"])
        if g_use and p_use: use_tp += 1
        elif not g_use and p_use: use_fp += 1
        elif g_use and not p_use: use_fn += 1

        gm = g["months"].strip()
        if gm:
            mon_n += 1
            if p.get("months") is not None and abs(float(gm) - float(p["months"])) < 0.6:
                mon_ok += 1

        gi = set(x for x in g["issues"].split("|") if x.strip())
        if gi:
            iss_n += 1
            if gi == set(p.get("issues", [])):
                iss_ok += 1

        if g["sentiment"].strip() == p.get("sentiment"):
            sent_ok += 1

    prec = use_tp / (use_tp + use_fp) if use_tp + use_fp else 0
    rec  = use_tp / (use_tp + use_fn) if use_tp + use_fn else 0

    print(f"대조한 건수            {n}")
    print(f"─" * 42)
    print(f"사용 판단 정밀도       {prec*100:5.1f}%   목표 90%  {'OK' if prec>=.9 else '미달'}")
    print(f"사용 판단 재현율       {rec*100:5.1f}%   목표 80%  {'OK' if rec>=.8 else '미달'}")
    print(f"기간 정확도            {(mon_ok/mon_n*100 if mon_n else 0):5.1f}%   목표 90%  "
          f"{'OK' if mon_n and mon_ok/mon_n>=.9 else '미달'}   ({mon_ok}/{mon_n})")
    print(f"문제 유형 정확도       {(iss_ok/iss_n*100 if iss_n else 0):5.1f}%   목표 85%  "
          f"{'OK' if iss_n and iss_ok/iss_n>=.85 else '미달'}   ({iss_ok}/{iss_n})")
    print(f"감정 정확도            {(sent_ok/n*100 if n else 0):5.1f}%")
    print(f"─" * 42)
    if iss_n and iss_ok/iss_n < .85:
        print("\n문제 유형 정확도가 목표에 못 미칩니다.")
        print("01_extract.md 의 few-shot 예시에 틀린 사례를 추가하고 다시 재세요.")


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(__doc__); sys.exit(0)
    cmd = sys.argv[1]
    if cmd == "validate":
        comments = json.load(open(sys.argv[2], encoding="utf-8"))
        comments = {int(k): v for k, v in comments.items()}
        result = json.load(open(sys.argv[3], encoding="utf-8"))
        ok, bad = validate(comments, result)
        print(f"통과 {len(ok)}건 / 폐기 {len(bad)}건")
        for rid, why in bad:
            print(f"  [{rid}] {why}")
        if bad:
            print("\n폐기된 건은 사람 확인 대기열로 보냅니다.")
    elif cmd == "evaluate":
        evaluate(sys.argv[2], sys.argv[3])
    else:
        print(__doc__)
