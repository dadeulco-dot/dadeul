"""
다들 · 후보 제품 발굴 점수 계산
────────────────────────────────────────────────────────
「AI가 MD 역할을 대신한다」의 실제 구현.

핵심: 제미나이에게 "인기 제품 알려줘"라고 묻지 않는다.
      네 가지 신호를 API로 가져와 코드로 합산하고, 사람이 승인한다.

신호별 가중치는 파일럿 이후 실제 전환율을 보고 조정한다.
지금 값은 출발점일 뿐이며, 근거 없는 정밀함을 흉내 내지 않는다.
"""

from dataclasses import dataclass, field
from typing import Optional
import math


# ── 가중치 ─────────────────────────────────────────────
W = {
    "miss":    0.40,   # 다들에서 검색했는데 못 찾은 횟수  ← 가장 정직한 수요 신호
    "trend":   0.20,   # 검색량 3개월 추이
    "video":   0.20,   # 최근 6개월 리뷰 영상 수
    "problem": 0.20,   # 지식iN 문제 질문 수
}

# 이 점수를 넘어야 후보 목록에 올린다
CUTOFF = 45


@dataclass
class Signals:
    """모두 외부 API 또는 우리 DB에서 실제로 가져온 값.
    추정치를 넣지 않는다. 못 가져오면 None으로 두고 감점한다."""
    name: str
    brand: str
    category: str

    miss_count:   Optional[int] = None   # 우리 DB · 검색 실패 로그
    trend_ratio:  Optional[float] = None # 네이버 데이터랩 · 3개월 전 대비 배수
    video_count:  Optional[int] = None   # YouTube API · 최근 6개월 리뷰 영상
    problem_qna:  Optional[int] = None   # 네이버 검색 API · 지식iN 문제 질문

    # 제외 조건
    is_food:        bool = False   # 식품·소모품 (우리 카테고리 아님)
    price_krw:      Optional[int] = None
    brand_contact:  bool = True    # 브랜드 연락처 확보 여부


def _norm(v, lo, hi):
    """0~100으로 정규화. 값이 없으면 0점 (추정하지 않는다)"""
    if v is None:
        return 0.0
    return max(0.0, min(100.0, (v - lo) / (hi - lo) * 100))


def score(s: Signals) -> dict:
    parts = {
        "miss":    _norm(s.miss_count, 0, 60),
        "trend":   _norm((s.trend_ratio or 0) * 100, 80, 250),
        "video":   _norm(s.video_count, 0, 40),
        "problem": _norm(s.problem_qna, 0, 120),
    }
    total = sum(parts[k] * W[k] for k in W)

    # 신호가 비어 있으면 신뢰할 수 없으므로 감점
    missing = sum(1 for k in ("miss_count","trend_ratio","video_count","problem_qna")
                  if getattr(s, k) is None)
    if missing:
        total *= (1 - 0.15 * missing)

    return {"total": round(total, 1), "parts": {k: round(v,1) for k,v in parts.items()},
            "missing_signals": missing}


def screen(s: Signals) -> list:
    """제외 사유. 하나라도 있으면 후보에서 뺀다."""
    out = []
    if s.is_food:
        out.append("식품·소모품은 다루지 않아요")
    if s.price_krw is not None and s.price_krw < 8000:
        out.append("가격이 낮아 협상 여지가 없어요")
    if s.price_krw is not None and s.price_krw > 400000:
        out.append("고가라 공동구매 수요가 얇아요")
    if not s.brand_contact:
        out.append("브랜드 연락처가 없어 협상할 수 없어요")
    return out


def rank(items: list) -> list:
    """후보 목록을 점수순으로. 운영 콘솔 「후보」 탭에 그대로 뿌린다."""
    rows = []
    for s in items:
        blocked = screen(s)
        sc = score(s)
        rows.append({
            "name": f"{s.brand} {s.name}",
            "category": s.category,
            "score": sc["total"],
            "parts": sc["parts"],
            "missing": sc["missing_signals"],
            "blocked": blocked,
            "pass": (not blocked) and sc["total"] >= CUTOFF,
        })
    rows.sort(key=lambda r: (-r["score"]))
    return rows


# ── 사용 예 ────────────────────────────────────────────
if __name__ == "__main__":
    sample = [
        Signals("스테인리스 3중 팬 28cm", "무이", "조리팬",
                miss_count=41, trend_ratio=1.6, video_count=22, problem_qna=68,
                price_krw=52000),
        Signals("세라믹 코팅팬 26cm", "세라", "조리팬",
                miss_count=12, trend_ratio=1.1, video_count=9, problem_qna=31,
                price_krw=29000),
        Signals("프리미엄 원두 1kg", "어떤커피", "식품",
                miss_count=55, trend_ratio=2.1, video_count=30, problem_qna=90,
                price_krw=32000, is_food=True),
        Signals("무쇠 그릴팬 24cm", "코르나", "무쇠·주물",
                miss_count=28, trend_ratio=None, video_count=15, problem_qna=44,
                price_krw=58000),
        Signals("실리콘 주걱", "노바", "조리도구",
                miss_count=6, trend_ratio=0.9, video_count=3, problem_qna=8,
                price_krw=6500),
    ]

    print(f"{'제품':28} {'점수':>6}  {'상태'}")
    print("─" * 72)
    for r in rank(sample):
        state = "후보 등록" if r["pass"] else (r["blocked"][0] if r["blocked"] else "점수 미달")
        warn = f"  (신호 {r['missing']}개 없음)" if r["missing"] else ""
        print(f"{r['name']:28} {r['score']:>6}  {state}{warn}")
    print("─" * 72)
    print(f"기준 점수 {CUTOFF}점 이상 · 제외 사유 없음 → 사람이 최종 승인")
