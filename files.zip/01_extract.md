# 후기 추출 프롬프트

아래 내용을 `00_system.md` 뒤에 붙여서 호출한다.
입력은 댓글 여러 건을 한 번에 넣는다 (권장 20~40건).

---

## 프롬프트 본문

```
아래는 특정 주방용품에 달린 사용자 댓글 목록이다.
각 댓글에서 값만 뽑아 JSON 배열로 반환한다.

## 뽑을 값

id           입력에 주어진 번호를 그대로
use          이 댓글을 후기로 셀 수 있는가 (true/false)
skip_reason  use가 false일 때만. 아래 목록에서 하나
months       사용 기간(개월). 숫자 또는 null
issues       문제 유형 배열. 아래 목록에서만. 없으면 []
merits       좋다고 한 점 배열. 아래 목록에서만. 없으면 []
sentiment    "긍정" | "부정" | "중립"
keep_using   지금도 쓰고 있다고 밝혔는가 (true/false)
disposed     버렸거나 교체했다고 밝혔는가 (true/false)
irony        비꼬거나 반어법인가 (true/false)
confidence   추출 확신도 "high" | "low"

## skip_reason 목록 (이것 외에는 쓰지 않는다)

"협찬"        대가를 받았다고 밝힘
"사용 전"     아직 안 써봤다 / 받기만 했다 / 살까 고민 중
"제품 무관"   다른 제품 이야기이거나 제품과 무관
"내용 없음"   인사, 이모지, 질문만 있는 글
"판단 불가"   무슨 말인지 알 수 없음

## issues 목록 (이것 외에는 쓰지 않는다)

"코팅박리"    눌어붙음, 코팅 벗겨짐, 들러붙음
"바닥변형"    뒤틀림, 바닥이 뜸, 우글거림, 덜그럭거림
"손잡이문제"  흔들림, 유격, 헐거움, 손잡이가 뜨거움
"무게부담"    무거움, 손목 부담
"세척불편"    설거지 힘듦, 얼룩, 잘 안 닦임
"변색녹"      변색, 녹슴, 누렇게 됨
"AS불만"      교환·환불 거부, 응대 불만, 연락 안 됨
"내구성"      깨짐, 파손, 수명이 짧음
"기능미흡"    열이 안 고름, 인덕션 인식 안 됨, 용량 부족

## merits 목록 (이것 외에는 쓰지 않는다)

"열효율"      열이 고르게 퍼짐, 빨리 달궈짐
"눌어붙지않음" 잘 안 눌어붙음, 코팅이 오래감
"가벼움"      가볍고 다루기 쉬움
"내구성좋음"  튼튼함, 오래 씀
"세척편함"    설거지 편함, 잘 닦임
"디자인"      예쁨, 마감이 좋음
"가격만족"    가격 대비 좋음
"AS만족"      응대가 좋았음

## months 규칙

- "3개월", "반년", "1년 반", "두 달" 처럼 **명시된 것만** 숫자로 바꾼다
  · 반년 → 6, 1년 반 → 18, 두 달 → 2
- 사용 맥락(쓰다/사용/굽다/볶다 등)이 함께 있을 때만 인정한다
- 배송 기간, 가격, 할인율에 붙은 숫자는 기간이 아니다
  · "배송 3일" → null,  "3만원대" → null
- "오래 썼다", "한참 됐다" 처럼 막연하면 null
- 범위는 작은 쪽을 쓴다: "2~3개월" → 2

## sentiment 규칙

- issues가 있고 merits가 없으면 "부정"
- merits가 있고 issues가 없으면 "긍정"
- 둘 다 있거나 둘 다 없으면 "중립"
- irony가 true면 겉으로 칭찬해도 "부정"

## confidence 규칙

다음 중 하나라도 해당하면 "low"
- 문장이 짧아 맥락이 부족함
- 비꼼인지 확신이 안 섬
- 여러 제품 이야기가 섞임
- issues 목록에 딱 맞는 항목이 없어 억지로 넣음

"low"인 건은 사람이 다시 본다. 애매하면 주저 말고 "low"로 한다.

## 출력 형식

JSON 배열만 출력한다. 앞뒤에 어떤 문자도 붙이지 않는다.

## 입력

<<<COMMENTS>>>
```

---

## 입력 형식 예

```
1. 저도 8개월째 쓰는데 아직 눌어붙는 건 없어요 예열만 잘하면 됩니다
2. 업체로부터 제품을 제공받아 작성했습니다
3. ㅋㅋㅋ
4. 3개월쯤 되니 슬슬 눌어붙기 시작하네요 아쉽습니다
5. 배송 3일 만에 왔어요
6. 무겁긴 한데 그만큼 튼튼해서 2년째 잘 쓰는 중
7. 참 좋은 제품이네요 두 달 만에 코팅 다 벗겨지고
```

## 기대 출력

```json
[
 {"id":1,"use":true,"months":8,"issues":[],"merits":["눌어붙지않음"],
  "sentiment":"긍정","keep_using":true,"disposed":false,"irony":false,"confidence":"high"},
 {"id":2,"use":false,"skip_reason":"협찬","months":null,"issues":[],"merits":[],
  "sentiment":"중립","keep_using":false,"disposed":false,"irony":false,"confidence":"high"},
 {"id":3,"use":false,"skip_reason":"내용 없음","months":null,"issues":[],"merits":[],
  "sentiment":"중립","keep_using":false,"disposed":false,"irony":false,"confidence":"high"},
 {"id":4,"use":true,"months":3,"issues":["코팅박리"],"merits":[],
  "sentiment":"부정","keep_using":false,"disposed":false,"irony":false,"confidence":"high"},
 {"id":5,"use":false,"skip_reason":"내용 없음","months":null,"issues":[],"merits":[],
  "sentiment":"중립","keep_using":false,"disposed":false,"irony":false,"confidence":"high"},
 {"id":6,"use":true,"months":24,"issues":["무게부담"],"merits":["내구성좋음"],
  "sentiment":"중립","keep_using":true,"disposed":false,"irony":false,"confidence":"high"},
 {"id":7,"use":true,"months":2,"issues":["코팅박리"],"merits":[],
  "sentiment":"부정","keep_using":false,"disposed":false,"irony":true,"confidence":"low"}
]
```

**7번이 이 프롬프트의 핵심 시험**입니다. "참 좋은 제품이네요"만 보면 긍정인데, 뒤에 붙은 내용이 반어입니다. `irony: true`와 `confidence: low`가 함께 나와야 정상입니다.

---

## 호출 후 반드시 할 검증 (코드에서)

제미나이 출력을 그대로 믿지 말고 아래를 확인한다. 하나라도 걸리면 그 건은 버린다.

| 검사 | 조건 |
|---|---|
| 목록 밖 값 | `issues`·`merits`·`skip_reason`이 정의된 목록에 없으면 폐기 |
| 개수 불일치 | 입력 건수와 출력 건수가 다르면 전체 재요청 |
| id 불일치 | id가 입력에 없던 값이면 폐기 |
| 기간 범위 | `months`가 0.5 미만이거나 240 초과면 null로 |
| 원문 대조 | `months`가 있는데 **원문에 숫자가 없으면 폐기** |

**마지막 검사가 가장 중요합니다.** 환각으로 만들어낸 기간을 잡아냅니다.
