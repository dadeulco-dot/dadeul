import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,pid:S.pid,brand:S.brand,q:S.q,안읽음:unreadN(),toast:S.toast})"
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',screen:'home',fav:{{p1:true,m2:true,m15:true}},requested:{{'유모차':true}},follow:{{'마마온':true}},readNoti:{{}},user:null}});draw()")
      async def c(sel,label,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        print(view,label,'' if ok else '(버튼 없음!)',await pg.evaluate(ST))
      print(view,'홈 종 표시:',await pg.evaluate("(document.querySelector('.bell .bdot,.gbtn[data-a=\"noti\"] .bdot')||{}).innerText"))
      await c('[data-a="noti"]','① 종 → 알림')
      print(view,'   목록:',await pg.evaluate("[...document.querySelectorAll('.nitem')].map(e=>e.querySelector('div div:nth-child(2)').innerText).join(' / ')"))
      await c('[data-a="nopen:n-p1"]','② 하로 알림 → 상세')
      await c('[data-a="dback"]' if view=='mo' else '[data-a="noti"]','③ 뒤로 → 알림')
      await c('[data-a="nopen:n-br-마마온"]','④ 브랜드 알림 → 브랜드')
      await c('[data-a="brandback"],.bback','⑤ 뒤로 → 알림')
      await c('[data-a="nopen:n-req-유모차"]','⑥ 요청 알림 → 검색')
      await c('[data-a="sback"]' if view=='mo' else '[data-a="noti"]','⑦ 뒤로 → 알림')
      await c('[data-a="notiread"]','⑧ 모두 읽음')
      await c('[data-a="sheet:login"]','⑨ 연결하기')
      await c('[data-a="login:naver"]','⑩ 네이버로')
      print(view,'   연결 후 첫 줄:',await pg.evaluate("document.querySelector('.notib div div').innerText"))
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
