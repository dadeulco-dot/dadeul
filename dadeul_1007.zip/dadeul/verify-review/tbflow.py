import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,brand:S.brand,pid:S.pid,lsub:S.lsub,mega:S.mega,follow:Object.keys(S.follow).filter(k=>S.follow[k]).join(','),toast:S.toast})"
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"S.view='{view}';S.screen='detail';S.pid='p2';S.resetTop=1;draw()")
      async def c(sel,label,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        print(view,label,'' if ok else '(버튼 없음!)',await pg.evaluate(ST))
      await c('.blink','① 상세의 브랜드 「무이」')
      print(view,'   무이 제품:',await pg.evaluate("[...document.querySelectorAll('.bgrp .fgh b')].map(e=>e.innerText).join(', ')"))
      await c('[data-a="follow:무이"]','② 새 제품 알림')
      await c('[data-a="brandback"]','③ 뒤로 → 상세')
      if view=='mo':
        await c('.tab[data-a=\"cats:\"]','④ (목록으로 가서) 카테고리') if False else None
        await pg.evaluate("S.screen='cats';S.prev=null;draw()");await c('[data-a="brands"]','④ 카테고리 → 브랜드로 찾기')
      else:
        await c('[data-a="mega:뷰티"]','④ 펼침 메뉴');await c('.mega [data-a="brands"]','④-2 브랜드로 찾기')
      await c('[data-a="bjump:ㅎ"]','⑤ 「ㅎ」으로 이동')
      await c('[data-a="brand:하로"]','⑥ 하로')
      await c('[data-a="brandback"]','⑦ 뒤로 → 모아보기')
      await pg.evaluate("Object.assign(S,{screen:'search',q:'마마',sqDone:false});draw()")
      await c('[data-a="brand:마마온"]','⑧ 검색 자동완성 브랜드 「마마온」')
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
