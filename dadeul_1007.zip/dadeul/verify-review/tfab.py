import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
OV="""()=>{const f=document.querySelector('.pfb').getBoundingClientRect();const hits=[];
 document.querySelectorAll('.bottom,.tabs,.cfloat,.tray,.gnb').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&!(f.right<=r.left||f.left>=r.right||f.bottom<=r.top||f.top>=r.bottom))hits.push(e.className)});
 return {fab:[Math.round(f.left),Math.round(f.top)],겹침:hits}}"""
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',360,780),('mo',390,844),('mo(PC 미리보기)',1280,900),('pc',1440,900)]:
      v='pc' if view=='pc' else 'mo'
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      res=[]
      for st in ["S.screen='home'","S.screen='list';S.lsub='프라이팬';S.cmp={}","S.screen='list';S.lsub='프라이팬';S.cmp={p1:1,m2:1}","S.screen='detail';S.pid='p1'","S.screen='compare';S.csub='프라이팬';S.cmp={p1:1,m2:1}","S.screen='cats'"]:
        await pg.evaluate(f"S.view='{v}';S.protoOpen=false;{st};S.resetTop=1;draw()")
        r=await pg.evaluate(OV);res.append((st.split(';')[0].split('=')[1].strip("'")+(' +비교함' if 'p1:1' in st and 'list' in st else ''),r['겹침'] or '없음'))
      print(view,W,'버튼과 막대 겹침:',res)
      # 열고 닫기
      await pg.evaluate(f"S.view='{v}';S.screen='home';draw()")
      await pg.click('.pfb');await pg.wait_for_timeout(100);o1=await pg.evaluate("S.protoOpen")
      await pg.click('.pfp [data-a="pick:p3"]');await pg.wait_for_timeout(150);o2=await pg.evaluate("({open:S.protoOpen,screen:S.screen,pid:S.pid})")
      await pg.click('.pfb');await pg.wait_for_timeout(100)
      box=await pg.evaluate("(()=>{const r=document.querySelector('.pfp').getBoundingClientRect();return [r.right+40,r.top+10]})()")
      await pg.mouse.click(min(box[0],W-10),box[1]);await pg.wait_for_timeout(100);o3=await pg.evaluate("S.protoOpen")
      print('   열기',o1,'→ 항목 고르면',o2,'→ 바깥 누르면 열림 상태',o3,'· JS 오류',errs)
      await pg.close()
    await b.close()
asyncio.run(m())
