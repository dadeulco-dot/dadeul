import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,q:S.q,done:S.sqDone,open:S.sOpen,recent:S.recentQ.join('|'),focus:document.activeElement&&document.activeElement.matches('[data-sq]'),lsub:S.lsub,req:Object.keys(S.requested).join(','),sug:document.querySelectorAll('[data-sres] .srow2').length,items:document.querySelectorAll('[data-sres] .lcard,.sgrid .lcard').length,toast:S.toast})"
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    # 모바일
    pg=await b.new_page(viewport={'width':390,'height':844});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300);await pg.evaluate("S.view='mo';S.screen='home';draw()")
    async def L(t):print('mo',t,await pg.evaluate(ST))
    await pg.click('.hsearch');await pg.wait_for_timeout(150);await L('① 홈 검색창 누름')
    await pg.keyboard.type('ㅍㄹㅇ',delay=30);await pg.wait_for_timeout(150);await L('② 「ㅍㄹㅇ」 입력 중')
    await pg.keyboard.press('Enter');await pg.wait_for_timeout(200);await L('③ Enter → 결과')
    await pg.click('[data-a="sclear"]');await pg.wait_for_timeout(150);await L('④ 지우기')
    await pg.keyboard.type('썬크림',delay=30);await pg.keyboard.press('Enter');await pg.wait_for_timeout(200);await L('⑤ 「썬크림」 → 결과 없음')
    await pg.click('[data-a^="sreq:"]');await pg.wait_for_timeout(150);await L('⑥ 후기 모아주세요')
    await pg.click('[data-a="sclear"]');await pg.wait_for_timeout(150);await L('⑦ 지우기 → 입력 전 (최근 검색)')
    await pg.click('[data-a="sdel:썬크림"]');await pg.wait_for_timeout(150);await L('⑧ 최근 검색 하나 지우기')
    await pg.click('.popq [data-a="sgo:젖병"]');await pg.wait_for_timeout(200);await L('⑨ 많이 찾는 말 「젖병」')
    await pg.click('.subcard');await pg.wait_for_timeout(200);await L('⑩ 「젖병 7종 비교하기」 카드 → 목록')
    await pg.click('.top .sbox');await pg.wait_for_timeout(150);await L('⑪ 목록 검색창 → 검색')
    await pg.click('[data-a="sback"]');await pg.wait_for_timeout(150);await L('⑫ 뒤로 → 원래 목록')
    print('mo 관심 신호에 검색어 반영:',await pg.evaluate("topSubs(interest()).slice(0,3).join(',')"))
    print('mo JS 오류',errs);await pg.close()
    # PC
    pg=await b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300);await pg.evaluate("S.view='pc';S.screen='home';draw()")
    async def P(t):print('pc',t,await pg.evaluate(ST))
    await pg.click('.gsw input');await pg.wait_for_timeout(200);await P('① 상단 검색창 누름 → 펼침')
    await pg.keyboard.type('수분',delay=30);await pg.wait_for_timeout(150);await P('② 「수분」 입력 중')
    await pg.keyboard.press('Escape');await pg.wait_for_timeout(100);await P('③ Esc → 입력 비움')
    await pg.keyboard.press('Escape');await pg.wait_for_timeout(100);await P('④ Esc 한 번 더 → 닫힘')
    await pg.click('.gsw input');await pg.keyboard.type('하로',delay=30);await pg.wait_for_timeout(100)
    await pg.click('.sdrop [data-a="sgo:하로"]');await pg.wait_for_timeout(200);await P('⑤ 자동완성 브랜드 「하로」 → 결과 화면')
    await pg.click('.gsw input');await pg.wait_for_timeout(150)
    await pg.mouse.click(1300,700);await pg.wait_for_timeout(150);await P('⑥ 바깥 누름 → 닫힘')
    print('pc JS 오류',errs);await b.close()
asyncio.run(m())
