import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"S.view='{view}';S.screen='list';draw()")
      st=lambda: pg.evaluate("()=>({screen:S.screen,pid:S.pid,lsub:S.lsub,lsort:S.lsort,f:JSON.stringify(S.f),cmp:Object.keys(S.cmp).join(','),toast:S.toast,sheet:S.sheet})")
      log=[]
      async def click(sel,label):
        await pg.evaluate(f"document.querySelector('{sel}').click()");await pg.wait_for_timeout(150);log.append((label,await st()))
      await click('[data-a="kcat:coat"]','기준: 코팅 내구성')
      first=await pg.evaluate("(document.querySelector('.lcard .lname')||document.querySelector('.ltable tbody tr td div div:nth-child(2)')).innerText")
      log.append(('  → 맨 위 제품',first))
      await click('[data-a="kcat:coat"]','기준 한 번 더 (풀기)')
      await click('[data-a="cmp:m2"]','목록에서 프리모 담기')
      await click('[data-a="cmp:m3"]','노바 담기')
      await click('[data-a="open:m2"]','목록용 제품 열기 (상세 없음)')
      await click('[data-a="open:p1"]','하로 열기 → 상세')
      await click(f'[data-a="list:프라이팬"]','경로 → 목록')
      if view=='mo':
        await click('[data-a="sheet:filter"]','필터 창');await click('[data-a="fgood"]','「대체로 만족」만');await pg.evaluate("S.f.pmin=30000;S.f.pmax=50000;S.keepTop=1;draw()");log.append(('3만~5만 원 범위',await st()))
        cnt=await pg.evaluate("document.querySelector('.sheet .main').innerText");log.append(('  → 창 버튼',cnt))
        await click('.sheet .main','결과 보기')
      else:
        await click('[data-a="fgood"]','「대체로 만족」만');await pg.evaluate("S.f.pmin=30000;S.f.pmax=50000;S.keepTop=1;draw()");log.append(('3만~5만 원 범위',await st()))
      n=await pg.evaluate("document.querySelectorAll('.lcard,.ltable tbody tr').length");log.append(('  → 보이는 제품 수',n))
      await click('[data-a="freset"]','필터 풀기')
      await click('.pfb','샘플 버튼 열기')
      await click('.pfp [data-a="list:크림"]','크림 목록')
      log.append(('  → 단위 가격 정렬 있음',await pg.evaluate("SORTS('크림').some(x=>x[0]==='unit')")))
      for k,v in log: print(view,k,v)
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
