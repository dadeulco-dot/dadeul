import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
SNAP="""()=>{const h=homeParts();const I=h.I;return {대분류:h.dom,관심:topSubs(I).slice(0,3).map(s=>s+' '+I.subs[s].toFixed(1)).join(', ')||'없음',
 맞춤제목:(document.querySelector('.fysec .t-h')||{}).innerText||'(없음)',맞춤:forYou(I).map(x=>x.brand).join('·'),
 탭:rankSub(),별점만:h.gaps.map(x=>x.brand).join('·'),새로:h.newly.map(x=>x.brand).join('·'),고민:[...document.querySelectorAll('.tcard > div:first-child')].map(e=>e.innerText).join('·'),
 이유:(document.querySelector('.why2')||{}).innerText||''}}"""
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch();pg=await b.new_page(viewport={'width':390,'height':844});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL);await pg.wait_for_timeout(300)
    await pg.evaluate("S.view='mo';draw()")
    async def via(a,label):
      await pg.evaluate("S.protoOpen=true;draw()");await pg.evaluate(f"document.querySelector('.pfp [data-a=\"{a}\"]').click()");await pg.wait_for_timeout(150)
      r=await pg.evaluate(SNAP);print('■',label);[print('   ',k,':',v) for k,v in r.items()];return r
    a=await via('home','① 처음 온 사람 (기록 없음)')
    await via('demoEntry','② 검색으로 처음 온 사람 「아기 젖병」')
    r1=await via('demo1','③ 다시 온 사람 (크림·프라이팬 관심)')
    await pg.evaluate("S.keepTop=1;draw()");await pg.wait_for_timeout(100)   # 같은 화면을 실제로 다시 그림 (예전엔 동작 없는 탭을 눌러 늘 통과했음)
    r1b=await pg.evaluate(SNAP);print('■ 같은 화면을 다시 그림 → 그대로인가:',r1b['별점만']==r1['별점만'] and r1b['맞춤']==r1['맞춤'] and r1b['새로']==r1['새로'])
    seen=set()
    for i in range(6):
      await pg.evaluate("S.protoOpen=true;draw()");await pg.evaluate("document.querySelector('.pfp [data-a=\"reseed\"]').click()");await pg.wait_for_timeout(80)
      r=await pg.evaluate(SNAP);seen.add((r['맞춤'],r['별점만'],r['새로'],r['고민']))
    print('■ 새로고침 6번 → 서로 다른 조합',len(seen),'가지 (대분류는 그대로:',r['대분류'],')')
    await pg.evaluate("document.querySelector('[data-a=\"poff\"]').click()");await pg.wait_for_timeout(100)
    r=await pg.evaluate(SNAP);print('■ 맞춤 끄기 →',{k:r[k] for k in ['대분류','관심','맞춤제목','이유']})
    await pg.evaluate("document.querySelector('[data-a=\"poff\"]').click()");await pg.wait_for_timeout(100)
    await pg.evaluate("document.querySelector('[data-a=\"hdom:육아용품\"]').click()");await pg.wait_for_timeout(100)
    r=await pg.evaluate(SNAP);print('■ 직접 육아용품 고름 →',r['대분류'],'/ 탭',r['탭'])
    print('JS 오류',errs);await b.close()
asyncio.run(m())
