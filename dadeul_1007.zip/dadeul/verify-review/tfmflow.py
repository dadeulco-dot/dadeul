import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,seg:S.favSeg,joins:Object.keys(S.joins).filter(k=>S.joins[k]).join(','),did:S.did,toast:S.toast})"
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"Object.assign(S,{{view:'{view}',moaOn:true,screen:'home',fav:{{p1:true,m2:true}},joins:{{d1:true,d2:true,d3:true,d5:true}},favSeg:'fav'}});draw()")
      async def c(sel,label,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        print(view,label,'' if ok else '(버튼 없음!)',await pg.evaluate(ST))
      if view=='mo': print(view,'하단 탭 찜 숫자:',await pg.evaluate("document.querySelector('.tab[data-a=\"favs\"] span').innerText"))
      await c('.tab[data-a="favs"]' if view=='mo' else '.gbtn[data-a="favs"]','① 찜 탭')
      print(view,'   전환 칸:',await pg.evaluate("document.querySelector('.fseg').innerText.replace(/\\n/g,' ')"),'· 열린 제품 점',await pg.evaluate("!!document.querySelector('.fseg .sdot')"))
      await c('[data-a="favseg:moa"]','② 모아 사기 칸')
      print(view,'   묶음:',await pg.evaluate("[...document.querySelectorAll('.fgrp .fgh b')].map(e=>e.innerText).join(' / ')"))
      print(view,'   줄:',await pg.evaluate("[...document.querySelectorAll('.mrow2 .mrl')].map(e=>e.innerText.replace(/\\n/g,' ')).join(' | ')"))
      await c('.mrow2 [data-a="deal:d1"]','③ 열린 하로 누름 → 모아 사기 상세')
      await c('[data-a="dealback"]' if view=='mo' else '.gbtn[data-a="favs"]','④ 뒤로 → 찜 (모아 사기 칸 유지)')
      await c('[data-a="moaleave:d2"]','⑤ 프리모 참여 취소')
      await c('[data-a="favseg:fav"]','⑥ 찜 칸으로')
      await pg.evaluate("S.protoOpen=true;draw()");await c('.pfp [data-a="moaon"]','⑦ 모아 사기 탭 숨기기')
      await pg.evaluate("Object.assign(S,{screen:'favs'});draw()")
      print(view,'   숨긴 뒤 전환 칸:',await pg.evaluate("!!document.querySelector('.fseg')"),'· 제목',await pg.evaluate("(document.querySelector('.top div,.t-title')||{}).innerText"))
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
