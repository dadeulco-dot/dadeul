import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
ST="""()=>{const r=document.getElementById('crow'),rr=r.getBoundingClientRect();
 const on=document.querySelector('.crow .chip.on');const o=on&&on.getBoundingClientRect();
 return {x:Math.round(r.scrollLeft),L:document.querySelector('.carr.l').classList.contains('show'),R:document.querySelector('.carr.r').classList.contains('show'),
  on:on?on.textContent.trim():null,full:on?(o.left>=rr.left-1&&o.right<=rr.right+1):null}}"""
async def run(pg,view):
  out=[]
  await pg.evaluate(f"S.view='{view}';S.screen='detail';S.pid='p1';S.act=null;S.crowXs={{}};S.resetTop=1;draw()");await pg.wait_for_timeout(200)
  if view=='mo':
    await pg.evaluate("const sc=document.getElementById('scr');sc.scrollTop=document.getElementById('c-coat').offsetTop-110");await pg.wait_for_timeout(700)
  out.append(('처음',await pg.evaluate(ST)))
  await pg.click('.carr.r button');await pg.wait_for_timeout(600);out.append(('→ 누름',await pg.evaluate(ST)))
  await pg.click('.carr.l button');await pg.wait_for_timeout(600);out.append(('← 누름',await pg.evaluate(ST)))
  # 반쯤 잘린 마지막 칩을 누름
  await pg.evaluate("document.querySelector('[data-a=\"go:exp\"]').click()");await pg.wait_for_timeout(1200);out.append(('구매 경험 누름',await pg.evaluate(ST)))
  # 본문을 위로 올려 첫 카테고리가 보이게
  if view=='pc': await pg.evaluate("window.scrollTo(0,document.getElementById('c-heat').getBoundingClientRect().top+scrollY-175)")
  else: await pg.evaluate("const sc=document.getElementById('scr');sc.scrollTop=document.getElementById('c-heat').offsetTop-100")
  await pg.wait_for_timeout(900);out.append(('본문을 열 전달로 스크롤',await pg.evaluate(ST)))
  await pg.evaluate("document.querySelector('[data-a=\"go:defect\"]').click()");await pg.wait_for_timeout(1200)
  x1=await pg.evaluate(ST)
  await pg.evaluate("document.querySelector('[data-a=\"month\"]').click()");await pg.wait_for_timeout(300)
  out.append(('초기 불량 누른 뒤 스위치 켬(다시 그림)',{'전':x1['x'],'후':(await pg.evaluate(ST))['x']}))
  return out
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('pc',1440,900),('mo',390,844)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      print('==',view);[print('  ',k,v) for k,v in await run(pg,view)];print('   오류',errs)
      await pg.close()
    await b.close()
asyncio.run(m())
