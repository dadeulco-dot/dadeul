import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"S.view='{view}';S.screen='detail';S.pid='p3';S.month=false;S.resetTop=1;draw()")
      st="()=>({screen:S.screen,k:S.storyK,month:S.month,lsub:S.lsub,lsort:S.lsort,top:S.view==='pc'?Math.round(scrollY):Math.round(document.getElementById('scr').scrollTop)})"
      async def c(sel,label,w=200):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        print(view,label,'' if ok else '(버튼 없음!)',await pg.evaluate(st))
      await c('#c-absorb [data-a="story:absorb"]','① 「흡수·끈적임」 이 이야기만 자세히')
      print(view,'   제목:',await pg.evaluate("document.querySelector('h1.t-title').innerText.trim()"),'/ 한 달:',await pg.evaluate("[...document.querySelectorAll('.stsec .t-body')].map(e=>e.innerText.replace(/\\n/g,' ')).find(t=>t.includes('한 달'))"))
      await c('[data-a="month"]','② 한 달 써 본 분만 켜기')
      await c('[data-a="storyback"]','③ 뒤로 → 상세 (그 카테고리 위치)')
      print(view,'   상세에서 흡수·끈적임 카드가 화면 위쪽에 있나:',await pg.evaluate("(()=>{const r=document.getElementById('c-absorb').getBoundingClientRect();return r.top>=0&&r.top<260})()"))
      await c('#c-moist [data-a="story:moist"]','④ 「보습·유지력」 자세히')
      await c('.prow:not(.me)','⑤ 비교 막대에서 다른 제품')
      await pg.evaluate("Object.assign(S,{screen:'detail',pid:'p3'});draw()")
      await c('#c-moist [data-a="story:moist"]','⑥ 원래 제품에서 다시 자세히')
      await c('[data-a="theme:크림:moist"]','⑦ 이 기준으로 목록 보기')
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
