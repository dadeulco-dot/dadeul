import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"S.view='{view}';S.screen='list';S.cmp={{}};draw()")
      st=lambda: pg.evaluate("()=>({screen:S.screen,sub:S.csub||'',pair:(S.cpair||[]).join(','),cmp:Object.keys(S.cmp).join(','),diff:S.cdiff,rows:document.querySelectorAll('.crw,.pcgr').length,toast:S.toast})")
      async def click(sel,label):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(150)
        print(view,label,'' if ok else '(버튼 없음!)',await st())
      await click('[data-a="cmp:p1"]','목록에서 하로 담기')
      await click('.cgo,.tgo','하나만 담고 비교하기')
      await click('[data-a="cmp:m2"]','프리모 담기')
      await click('[data-a="compare:프라이팬"].cgo,[data-a="compare:프라이팬"].tgo','비교하기 → 비교 화면')
      await click('[data-a="cdiff"]','차이 큰 것만 끄기')
      await click('[data-a="cdiff"]','다시 켜기')
      await click('[data-a="cmpback"]' if view=='mo' else '[data-a="list:프라이팬"]','뒤로/목록으로')
      await click('[data-a="cmp:m12"]','마레 담기');await click('[data-a="cmp:p2"]','무이 담기')
      await click('[data-a="cmp:m3"]','노바 담기 (5번째 → 막혀야 함)')
      await click('[data-a="compare:프라이팬"]','비교함 (탭/상단)')
      if view=='mo':
        await click('[data-a="cpick:m12"]','마레 골라 보기');await click('[data-a="cpick:p2"]','무이 골라 보기')
      await click('[data-a="rmcmp:p2"]','무이 빼기')
      await click('[data-a="open:p1"]','머리의 하로 누르기 → 상세')
      await click('.bottom .main,.pmainbtn','상세의 「같은 프라이팬 12종과 비교」')
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
