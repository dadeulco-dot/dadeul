import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
async def drag(pg,sel,frac):
  # 손잡이 중심을 잡아 막대 위 frac 위치로 끌어 놓음
  box=await pg.evaluate(f"""()=>{{const i=document.querySelector('{sel}'),r=i.getBoundingClientRect(),lo=+i.min,hi=+i.max,v=+i.value;
    return {{x:r.left+14+(r.width-28)*(v-lo)/(hi-lo),y:r.top+r.height/2,l:r.left+14,w:r.width-28}}}}""")
  await pg.mouse.move(box['x'],box['y']);await pg.mouse.down()
  await pg.mouse.move(box['l']+box['w']*frac,box['y'],steps=8);await pg.mouse.up();await pg.wait_for_timeout(200)
st="()=>({pmin:S.f.pmin,pmax:S.f.pmax,shown:document.querySelector('.rvals').innerText.replace(/\\s+/g,' '),count:(document.querySelector('.sheet .main')||{innerText:''}).innerText||document.querySelectorAll('.ltable tbody tr').length})"
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"S.view='{view}';S.screen='list';S.lsub='프라이팬';S.sheet={'\"filter\"' if view=='mo' else 'null'};S.resetTop=1;draw()")
      print('==',view,'처음',await pg.evaluate(st))
      await drag(pg,'.rng input[data-r="a"]',0.3);print('  왼쪽 손잡이 → 30%',await pg.evaluate(st))
      await drag(pg,'.rng input[data-r="b"]',0.7);print('  오른쪽 손잡이 → 70%',await pg.evaluate(st))
      await drag(pg,'.rng input[data-r="b"]',0.05);print('  오른쪽을 왼쪽 너머로 (넘어가면 안 됨)',await pg.evaluate(st))
      # 둘 다 오른쪽 끝으로 몬 뒤 왼쪽 손잡이를 다시 잡을 수 있는지
      await pg.evaluate("S.f.pmin=null;S.f.pmax=null;S.keepTop=1;draw()")
      await drag(pg,'.rng input[data-r="a"]',1.0);print('  왼쪽을 끝까지',await pg.evaluate(st))
      await drag(pg,'.rng input[data-r="a"]',0.5);print('  끝에 몰린 왼쪽을 다시 잡아 50%',await pg.evaluate(st))
      # 키보드
      await pg.evaluate("S.f.pmin=null;S.f.pmax=null;S.keepTop=1;draw()")
      await pg.focus('.rng input[data-r="b"]');await pg.keyboard.press('ArrowLeft');await pg.keyboard.press('ArrowLeft');await pg.wait_for_timeout(150)
      print('  키보드 ← 두 번 (최고가)',await pg.evaluate(st))
      await pg.evaluate("document.querySelector('[data-a=\"freset\"]').click()");await pg.wait_for_timeout(100)
      print('  초기화',await pg.evaluate(st))
      print('  JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
