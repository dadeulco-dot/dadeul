import sys,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import URL,CHK as _CHK
import asyncio
from playwright.async_api import async_playwright
ST="()=>({screen:S.screen,찜:Object.keys(S.fav).filter(k=>S.fav[k]).length,user:S.user&&S.user.ch,sheet:S.sheet,알림:Object.entries(S.notiPref).filter(x=>x[1]).length,비교함:Object.keys(S.cmp).join(','),csub:S.csub,요청:Object.keys(S.requested).join(','),toast:S.toast})"
async def m():
  async with async_playwright() as pw:
    b=await pw.chromium.launch()
    for view,W,H in [('mo',390,844),('pc',1440,900)]:
      pg=await b.new_page(viewport={'width':W,'height':H});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL);await pg.wait_for_timeout(300)
      await pg.evaluate(f"S.view='{view}';S.screen='home';S.fav={{}};S.requested={{'썬크림':true}};draw()")
      async def c(sel,label,w=150):
        ok=await pg.evaluate(f"(()=>{{const e=document.querySelector('{sel}');if(!e)return false;e.click();return true}})()");await pg.wait_for_timeout(w)
        print(view,label,'' if ok else '(버튼 없음!)',await pg.evaluate(ST))
      await c('.tab[data-a=\"favs\"]' if view=='mo' else '.gbtn[data-a="favs"]','① 찜 열기 (빈 상태 · 요청 1개)')
      print(view,'   빈 상태 문구:',await pg.evaluate("(document.querySelector('.t-h')||{}).innerText"))
      await c('[data-a="unreq:썬크림"]','② 요청 취소')
      await pg.evaluate("S.screen='list';S.lsub='프라이팬';draw()")
      for id in ['m2','m3','p1']: await c(f'[data-a="fav:{id}"]',f'③ 목록에서 {id} 찜')
      await c('.tab[data-a=\"favs\"]' if view=='mo' else '.gbtn[data-a="favs"]','④ 찜 다시 열기')
      await c('[data-a="sheet:login"]','⑤ 알림 받기 → 연결 창')
      await c('[data-a="login:kakao"]','⑥ 카카오로 계속')
      await c('[data-a="sheet:noti"]','⑦ 알림 설정 창')
      await c('[data-a="notipref:label"]','⑧ 「결과가 바뀌면」 끄기')
      await c('[data-a="close"]','⑨ 닫기')
      await c('[data-a="favcmp:프라이팬"]','⑩ 「비교함에 담아 비교하기」')
      await c('.tab[data-a=\"favs\"]' if view=='mo' else '.gbtn[data-a="favs"]','⑪ 찜으로')
      await c('.frow [data-a="fav:m3"]','⑫ 노바 찜 풀기')
      print(view,'JS 오류',errs);await pg.close()
    await b.close()
asyncio.run(m())
